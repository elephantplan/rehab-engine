package com.rehabengine

import android.app.Activity
import android.content.Intent
import com.facebook.react.bridge.ActivityEventListener
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.ReadableMap
import com.rehabengine.core.ModelStore
import com.rehabengine.core.RehabEngineActivity

/**
 * The thin React Native bridge: JS calls open(), this starts the native exercise screen and
 * resolves with its result. Same contract as the iOS bridge.
 */
class RehabEngineModule(context: ReactApplicationContext) :
  ReactContextBaseJavaModule(context), ActivityEventListener {

  companion object {
    const val NAME = "RehabEngine"
    private const val REQUEST_CODE = 0x5245 // "RE"
  }

  private var pending: Promise? = null

  init {
    context.addActivityEventListener(this)
  }

  override fun getName(): String = NAME

  /** The native SDK version, so a separately shipped JS bundle can check what this app contains. */
  override fun getConstants(): Map<String, Any> = mapOf("nativeVersion" to "0.0.10")

  private fun configureModels(options: ReadableMap) {
    if (!options.hasKey("modelUrls")) return
    val urls = options.getMap("modelUrls") ?: return
    ModelStore.configure(
      reactApplicationContext,
      if (urls.hasKey("pose")) urls.getString("pose") else null,
      if (urls.hasKey("hand")) urls.getString("hand") else null,
    )
  }

  @ReactMethod
  fun preload(options: ReadableMap, promise: Promise) {
    configureModels(options)
    val exercises = if (options.hasKey("exercises")) {
      options.getArray("exercises")?.toArrayList()?.mapNotNull { it as? String }.orEmpty()
    } else {
      emptyList()
    }
    val kinds = (if (exercises.isEmpty()) listOf("raise", "pinch") else exercises).map(ModelStore::kindFor).toSet()
    val context = reactApplicationContext
    Thread {
      try {
        kinds.forEach { ModelStore.ensure(context, it) }
        promise.resolve(null)
      } catch (e: Exception) {
        promise.reject("model_download_failed", e.message ?: "下載 model 失敗")
      }
    }.start()
  }

  @ReactMethod
  fun open(options: ReadableMap, promise: Promise) {
    val activity = reactApplicationContext.currentActivity
    if (activity == null) {
      promise.reject("no_activity", "No activity to present from")
      return
    }
    if (pending != null) {
      promise.reject("busy", "An exercise screen is already open")
      return
    }
    configureModels(options)
    val exercise = if (options.hasKey("exercise")) options.getString("exercise") ?: "raise" else "raise"
    pending = promise
    activity.startActivityForResult(RehabEngineActivity.intent(activity, exercise), REQUEST_CODE)
  }

  override fun onActivityResult(activity: Activity, requestCode: Int, resultCode: Int, data: Intent?) {
    if (requestCode != REQUEST_CODE) return
    val promise = pending ?: return
    pending = null
    if (resultCode == Activity.RESULT_OK && data != null) {
      val result = Arguments.createMap()
      val degrees = data.getStringExtra(RehabEngineActivity.EXTRA_UNIT) != "ratio"
      // Angles as whole degrees, ratios to two decimals, the same as iOS.
      fun number(v: Float): Double = if (degrees) Math.round(v).toDouble() else Math.round(v * 100) / 100.0
      result.putString("exercise", data.getStringExtra(RehabEngineActivity.EXTRA_EXERCISE) ?: "raise")
      result.putString("unit", if (degrees) "degrees" else "ratio")
      result.putInt("reps", data.getIntExtra(RehabEngineActivity.EXTRA_REPS, 0))
      result.putDouble("durationMs", data.getLongExtra(RehabEngineActivity.EXTRA_DURATION_MS, 0L).toDouble())
      result.putDouble("startedAt", data.getLongExtra(RehabEngineActivity.EXTRA_STARTED_AT, 0L).toDouble())
      if (data.hasExtra(RehabEngineActivity.EXTRA_BEST)) {
        result.putDouble("best", number(data.getFloatExtra(RehabEngineActivity.EXTRA_BEST, 0f)))
      } else {
        result.putNull("best")
      }
      val peaks = data.getFloatArrayExtra(RehabEngineActivity.EXTRA_REP_PEAKS) ?: FloatArray(0)
      val durations = data.getLongArrayExtra(RehabEngineActivity.EXTRA_REP_DURATIONS_MS) ?: LongArray(0)
      val sides = data.getStringArrayExtra(RehabEngineActivity.EXTRA_REP_SIDES) ?: emptyArray()
      val details = Arguments.createArray()
      for (i in peaks.indices) {
        val rep = Arguments.createMap()
        rep.putDouble("peak", number(peaks[i]))
        rep.putDouble("durationMs", durations.getOrElse(i) { 0L }.toDouble())
        val side = sides.getOrNull(i)
        if (side.isNullOrEmpty()) rep.putNull("side") else rep.putString("side", side)
        details.pushMap(rep)
      }
      result.putArray("repDetails", details)
      result.putDouble("trackingRatio", data.getDoubleExtra(RehabEngineActivity.EXTRA_TRACKING_RATIO, 0.0))
      promise.resolve(result)
    } else {
      promise.reject("cancelled", "The patient cancelled")
    }
  }

  override fun onNewIntent(intent: Intent) {}
}
