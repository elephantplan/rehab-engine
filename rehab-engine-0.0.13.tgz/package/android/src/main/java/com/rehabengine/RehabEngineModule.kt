package com.rehabengine

import android.app.Activity
import android.content.Intent
import com.facebook.react.bridge.ActivityEventListener
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.WritableArray
import com.facebook.react.bridge.WritableMap
import org.json.JSONArray
import org.json.JSONObject
import com.rehabengine.core.ModelStore
import com.rehabengine.core.RehabEngineActivity

/**
 * The thin React Native bridge: JS calls open(), this starts the native exercise screen and
 * resolves with its result. Same contract as the iOS bridge.
 */
class RehabEngineModule(context: ReactApplicationContext) :
  ReactContextBaseJavaModule(context), ActivityEventListener {

  companion object {
    const val NAME = "RehabEngine"
    private const val REQUEST_CODE = 0x5245 // "RE"
  }

  private var pending: Promise? = null

  init {
    context.addActivityEventListener(this)
  }

  override fun getName(): String = NAME

  /** The native SDK version, so a separately shipped JS bundle can check what this app contains. */
  override fun getConstants(): Map<String, Any> = mapOf("nativeVersion" to RehabEngineActivity.SDK_VERSION)

  private fun configureModels(options: ReadableMap) {
    if (!options.hasKey("modelUrls")) return
    val urls = options.getMap("modelUrls") ?: return
    ModelStore.configure(
      reactApplicationContext,
      if (urls.hasKey("pose")) urls.getString("pose") else null,
      if (urls.hasKey("hand")) urls.getString("hand") else null,
    )
  }

  @ReactMethod
  fun preload(options: ReadableMap, promise: Promise) {
    configureModels(options)
    val exercises = if (options.hasKey("exercises")) {
      options.getArray("exercises")?.toArrayList()?.mapNotNull { it as? String }.orEmpty()
    } else {
      emptyList()
    }
    val kinds = (if (exercises.isEmpty()) listOf("raise", "pinch") else exercises).map(ModelStore::kindFor).toSet()
    val context = reactApplicationContext
    Thread {
      try {
        kinds.forEach { ModelStore.ensure(context, it) }
        promise.resolve(null)
      } catch (e: Exception) {
        promise.reject("model_download_failed", e.message ?: "下載 model 失敗")
      }
    }.start()
  }

  @ReactMethod
  fun open(options: ReadableMap, promise: Promise) {
    val activity = reactApplicationContext.currentActivity
    if (activity == null) {
      promise.reject("no_activity", "No activity to present from")
      return
    }
    if (pending != null) {
      promise.reject("busy", "An exercise screen is already open")
      return
    }
    configureModels(options)
    val exercise = if (options.hasKey("exercise")) options.getString("exercise") ?: "raise" else "raise"
    pending = promise
    activity.startActivityForResult(RehabEngineActivity.intent(activity, exercise), REQUEST_CODE)
  }

  override fun onActivityResult(activity: Activity, requestCode: Int, resultCode: Int, data: Intent?) {
    if (requestCode != REQUEST_CODE) return
    val promise = pending ?: return
    pending = null
    val json = data?.getStringExtra(RehabEngineActivity.EXTRA_RESULT)
    if (resultCode == Activity.RESULT_OK && json != null) {
      promise.resolve(toWritable(JSONObject(json)))
    } else {
      promise.reject("cancelled", "The patient cancelled")
    }
  }

  override fun onNewIntent(intent: Intent) {}

  // The exercise screen hands back its result as JSON; turn it into the map JS receives.
  private fun toWritable(obj: JSONObject): WritableMap {
    val map = Arguments.createMap()
    obj.keys().forEach { key ->
      when (val v = obj.get(key)) {
        JSONObject.NULL -> map.putNull(key)
        is JSONObject -> map.putMap(key, toWritable(v))
        is JSONArray -> map.putArray(key, toWritable(v))
        is Boolean -> map.putBoolean(key, v)
        is Int -> map.putInt(key, v)
        is Number -> map.putDouble(key, v.toDouble())
        else -> map.putString(key, v.toString())
      }
    }
    return map
  }

  private fun toWritable(array: JSONArray): WritableArray {
    val out = Arguments.createArray()
    for (i in 0 until array.length()) {
      when (val v = array.get(i)) {
        JSONObject.NULL -> out.pushNull()
        is JSONObject -> out.pushMap(toWritable(v))
        is JSONArray -> out.pushArray(toWritable(v))
        is Boolean -> out.pushBoolean(v)
        is Int -> out.pushInt(v)
        is Number -> out.pushDouble(v.toDouble())
        else -> out.pushString(v.toString())
      }
    }
    return out
  }
}
