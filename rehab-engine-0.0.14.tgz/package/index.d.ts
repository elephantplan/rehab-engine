/**
 * - raise   舉手過頭: either arm up over the head (face the camera)
 * - lateral 側平舉: both arms out to shoulder height together (face the camera)
 * - curl    屈手肘: bend the elbow (side-on)
 * - wrist   手腕屈伸: bend the wrist up or down (side-on, forearm in view)
 * - pinch   拇指對食指: touch thumb tip to index tip (palm to the camera; hand tracking)
 */
export type RehabExercise = 'raise' | 'lateral' | 'curl' | 'wrist' | 'pinch';

export type RehabSide = 'left' | 'right' | 'both' | null;

/**
 * Movements that make an exercise look done without the joint doing the work. Each counts once
 * it lasts 3 frames within a movement; the patient hears a cue the first time.
 * - trunkLean     trunk leans more than 15° from vertical (needs both hips in view) — raise, lateral, curl
 * - shoulderHike  shoulder-to-ear gap drops below 70% of its value at rest — raise (below 120°), lateral
 * - elbowBent     elbow under 150° while the arm should stay straight — raise, lateral
 * - upperArmSwing upper arm more than 35° away from the body — curl
 * - forearmMove   forearm turns more than 20° from its direction at rest — wrist
 * - fingersCurled middle, ring and little fingertips pulled in towards the wrist — pinch
 */
export type RehabCompensation =
  | 'trunkLean'
  | 'shoulderHike'
  | 'elbowBent'
  | 'upperArmSwing'
  | 'forearmMove'
  | 'fingersCurled';

/** All values are in the result's unit (degrees, or the pinch ratio). */
export type RehabEngineRep = {
  /**
   * Furthest value reached in this rep: the highest arm angle for raise and lateral, the smallest
   * joint angle for curl and wrist, the smallest thumb–index gap for pinch.
   */
  peak: number;
  /** Value at rest just before the movement began. */
  start: number;
  /** Range of motion: |peak − start|. */
  range: number;
  /** From leaving the rest position to coming back. */
  durationMs: number;
  /** Time spent in the target zone (beyond target.activeAt). */
  holdMs: number;
  /** When the movement began, from the start of the session. */
  atMs: number;
  /** The patient's side that did the rep ('both' for lateral), or null when unknown. */
  side: RehabSide;
  /** Compensations seen during this rep. */
  compensations: RehabCompensation[];
};

/** A movement that left rest but came back without reaching the target. */
export type RehabEngineAttempt = {
  peak: number;
  start: number;
  atMs: number;
  side: RehabSide;
  compensations: RehabCompensation[];
};

export type RehabEngineResult = {
  exercise: RehabExercise;
  /**
   * 'degrees' for angle exercises; 'ratio' for pinch (thumb–index gap over palm length: about 1
   * with the hand open, near 0 when the tips touch).
   */
  unit: 'degrees' | 'ratio';
  /** Reps that reached the target. Success rate: reps / (reps + attempts.length). */
  reps: number;
  durationMs: number;
  /** Session start, milliseconds since 1970 (Date.now() style). */
  startedAt: number;
  /** Furthest value toward the target in the whole session, or null when never tracked. */
  best: number | null;
  /** The zones this session was judged against: a rep reaches activeAt and returns to restAt. */
  target: { activeAt: number; restAt: number };
  /** One entry per counted rep, in order. */
  repDetails: RehabEngineRep[];
  /** Movements that did not reach the target, in order. */
  attempts: RehabEngineAttempt[];
  /**
   * For each check this exercise runs, how many reps and attempts showed it (0 included, so a
   * missing key means the check does not apply).
   */
  compensations: Partial<Record<RehabCompensation, number>>;
  /**
   * The measured value every intervalMs (about 5 a second), null while the patient was not
   * tracked: for an angle-over-time chart. At most 10 minutes.
   */
  series: { intervalMs: number; values: (number | null)[] };
  /** Share of analysed frames (0...1) where the patient was clearly in view. */
  trackingRatio: number;
  /** The targetReps asked for, or null without a target. */
  targetReps: number | null;
  /** Whether reps reached targetReps; null without a target. */
  completed: boolean | null;
  /** Native SDK version that produced this result. */
  sdkVersion: string;
  /** Where the model came from: "bundled" or its download URL (a versioned URL names the model version). */
  model: string;
};

/**
 * Where to download the AI model files from (HA's own server in production). Each is downloaded
 * once and kept on the phone; a new URL downloads it again, which is how a model is updated
 * without an app release. Unset: Google's public copies.
 */
export type RehabModelUrls = {
  /** Body model, used by raise, lateral, curl and wrist. */
  pose?: string;
  /** Hand model, used by pinch. */
  hand?: string;
};

export type RehabEngineOptions = {
  /** Which exercise to run. Defaults to 'raise'; unknown values also fall back to 'raise'. */
  exercise?: RehabExercise;
  /**
   * Reps prescribed for this session. The screen shows "3 / 10" and closes by itself with the
   * result once the target is reached. Unset or 0: no target; the patient taps 完成.
   */
  targetReps?: number;
  modelUrls?: RehabModelUrls;
};

export type RehabPreloadOptions = {
  /** Exercises to get models for. Empty or unset: all of them. */
  exercises?: RehabExercise[];
  modelUrls?: RehabModelUrls;
};

export declare const RehabEngine: {
  /** Opens the native exercise screen full screen (iOS and Android); resolves when the patient taps 完成, rejects with code "cancelled" on 取消. */
  open(options?: RehabEngineOptions): Promise<RehabEngineResult>;
  /**
   * Downloads the models in the background so the first exercise opens at once. Call it when
   * the mini app loads. Rejects with code "model_download_failed" (no network, bad URL).
   * open() also downloads a missing model itself, showing a message while it does.
   */
  preload(options?: RehabPreloadOptions): Promise<void>;
  /** True when the native module is built into the app. */
  isAvailable: boolean;
  /**
   * The native SDK version inside this app build, or null when not built in. A mini app shipped
   * as its own JS bundle can check this before calling open().
   */
  nativeVersion: string | null;
};
