// The thin React Native bridge: JS calls open(), this presents the native screen and resolves
// the promise with its result. This file is what stays as source when the UI becomes a binary.
#import <React/RCTBridgeModule.h>
#import <React/RCTUtils.h>
#import <UIKit/UIKit.h>

// Binary form: the UI comes from RehabEngineCore.xcframework. Source form: from this pod's Swift.
#if __has_include(<RehabEngineCore/RehabEngineCore-Swift.h>)
#import <RehabEngineCore/RehabEngineCore-Swift.h>
#elif __has_include(<RehabEngine/RehabEngine-Swift.h>)
#import <RehabEngine/RehabEngine-Swift.h>
#else
#import "RehabEngine-Swift.h"
#endif

@interface RehabEngineModule : NSObject <RCTBridgeModule>
@end

@implementation RehabEngineModule

RCT_EXPORT_MODULE(RehabEngine)

+ (BOOL)requiresMainQueueSetup
{
  return NO;
}

// The native SDK version, so a separately shipped JS bundle can check what this app contains.
- (NSDictionary *)constantsToExport
{
  return @{ @"nativeVersion": @"0.0.14" };
}

static void RehabConfigureModels(NSDictionary *options)
{
  NSDictionary *urls = options[@"modelUrls"];
  if ([urls isKindOfClass:[NSDictionary class]]) {
    id pose = urls[@"pose"];
    id hand = urls[@"hand"];
    [RehabModelStore configureWithPoseURL:[pose isKindOfClass:[NSString class]] ? pose : nil
                                  handURL:[hand isKindOfClass:[NSString class]] ? hand : nil];
  }
}

RCT_EXPORT_METHOD(preload:(NSDictionary *)options
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
  RehabConfigureModels(options);
  NSArray *requested = options[@"exercises"];
  NSArray<NSString *> *exercises = [requested isKindOfClass:[NSArray class]] && requested.count > 0
      ? requested
      : @[ @"raise", @"pinch" ];
  [RehabModelStore preloadWithExercises:exercises completion:^(NSString *error) {
    if (error != nil) {
      reject(@"model_download_failed", error, nil);
    } else {
      resolve(nil);
    }
  }];
}

RCT_EXPORT_METHOD(open:(NSDictionary *)options
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
  RehabConfigureModels(options);
  NSString *exercise = options[@"exercise"] ?: @"raise";
  id target = options[@"targetReps"];
  NSInteger targetReps = [target isKindOfClass:[NSNumber class]] ? [target integerValue] : 0;
  dispatch_async(dispatch_get_main_queue(), ^{
    UIViewController *top = RCTPresentedViewController();
    if (top == nil) {
      reject(@"no_view_controller", @"No view controller to present from", nil);
      return;
    }
    RehabEngineViewController *vc = [[RehabEngineViewController alloc]
        initWithExercise:exercise
              targetReps:targetReps
                onFinish:^(NSDictionary<NSString *, id> *result) { resolve(result); }
                onCancel:^{ reject(@"cancelled", @"The patient cancelled", nil); }];
    [top presentViewController:vc animated:YES completion:nil];
  });
}

@end
