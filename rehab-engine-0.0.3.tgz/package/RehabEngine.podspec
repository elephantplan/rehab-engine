Pod::Spec.new do |s|
  s.name          = 'RehabEngine'
  s.version       = '0.0.3'
  s.summary       = 'Vendor-style rehab SDK: native Swift camera, MediaPipe pose and UI behind a thin React Native bridge'
  s.homepage      = 'https://github.com/elephantplan/motion_app'
  s.license       = 'MIT'
  s.authors       = 'motion_app'
  s.platforms     = { :ios => '15.1' }
  s.source        = { :git => 'https://github.com/elephantplan/motion_app.git' }
  s.swift_version = '5.0'
  s.pod_target_xcconfig = { 'DEFINES_MODULE' => 'YES' }
  s.frameworks    = 'AVFoundation', 'UIKit'

  binary = File.join(__dir__, 'ios', 'Frameworks', 'RehabEngineCore.xcframework')
  if File.exist?(binary)
    # Shipped form: only the bridge is source; the UI is the prebuilt, closed-source binary
    # made by build-xcframework.sh.
    s.source_files        = 'ios/Bridge/**/*.{h,m}'
    s.vendored_frameworks = 'ios/Frameworks/RehabEngineCore.xcframework'
  else
    # Development form, before the binary is built: compile the UI from source.
    s.source_files        = 'ios/Bridge/**/*.{h,m}', 'ios/Core/**/*.swift'
  end

  s.dependency 'React-Core'
  # Google's official MediaPipe iOS SDK. The binary links against it but does not contain it.
  s.dependency 'MediaPipeTasksVision', '~> 0.10.14'
end
