// Expo config plugin: `"plugins": ["rehab-engine"]` in app.json writes the camera
// permission text into the app's Info.plist at prebuild. iOS only reads that key from
// the host app, so an SDK cannot add it at runtime; this just saves the manual edit.
// Bare React Native apps (no prebuild) add NSCameraUsageDescription to Info.plist instead.
const { withInfoPlist } = require('expo/config-plugins');

const DEFAULT_TEXT = '用鏡頭偵測復康動作';

module.exports = function withRehabEngine(config, props = {}) {
  return withInfoPlist(config, (cfg) => {
    // Keep the host app's own wording if it already asks for the camera.
    if (props.cameraPermission || !cfg.modResults.NSCameraUsageDescription) {
      cfg.modResults.NSCameraUsageDescription = props.cameraPermission || DEFAULT_TEXT;
    }
    return cfg;
  });
};
