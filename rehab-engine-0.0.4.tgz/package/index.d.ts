export type RehabEngineResult = {
  exercise: string;
  reps: number;
  durationMs: number;
};

export type RehabEngineOptions = {
  /** Exercise to show. The test build only displays it. */
  exercise?: string;
};

export declare const RehabEngine: {
  /** Opens the native exercise screen full screen; resolves when the patient taps 完成, rejects on 取消. */
  open(options?: RehabEngineOptions): Promise<RehabEngineResult>;
  /** True when the native module is built into the app. */
  isAvailable: boolean;
};
