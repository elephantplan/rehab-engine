// Thin JavaScript wrapper. All UI lives in the native side (ios/Core).
const { NativeModules, Platform } = require('react-native');

const native = NativeModules.RehabEngine;

const RehabEngine = {
  isAvailable: native != null,
  open(options = {}) {
    if (native == null) {
      return Promise.reject(
        new Error(
          Platform.OS === 'ios'
            ? 'RehabEngine native module not found: run pod install and rebuild the app'
            : 'RehabEngine is iOS only for now',
        ),
      );
    }
    return native.open({ exercise: options.exercise ?? 'raise' });
  },
};

module.exports = { RehabEngine };
