// The thin React Native bridge: JS calls open(), this presents the native screen and resolves
// the promise with its result. This file is what stays as source when the UI becomes a binary.
#import <React/RCTBridgeModule.h>
#import <React/RCTUtils.h>
#import <UIKit/UIKit.h>

// Binary form: the UI comes from RehabEngineCore.xcframework. Source form: from this pod's Swift.
#if __has_include(<RehabEngineCore/RehabEngineCore-Swift.h>)
#import <RehabEngineCore/RehabEngineCore-Swift.h>
#elif __has_include(<RehabEngine/RehabEngine-Swift.h>)
#import <RehabEngine/RehabEngine-Swift.h>
#else
#import "RehabEngine-Swift.h"
#endif

@interface RehabEngineModule : NSObject <RCTBridgeModule>
@end

@implementation RehabEngineModule

RCT_EXPORT_MODULE(RehabEngine)

+ (BOOL)requiresMainQueueSetup
{
  return NO;
}

RCT_EXPORT_METHOD(open:(NSDictionary *)options
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
  NSString *exercise = options[@"exercise"] ?: @"raise";
  dispatch_async(dispatch_get_main_queue(), ^{
    UIViewController *top = RCTPresentedViewController();
    if (top == nil) {
      reject(@"no_view_controller", @"No view controller to present from", nil);
      return;
    }
    RehabEngineViewController *vc = [[RehabEngineViewController alloc]
        initWithExercise:exercise
                onFinish:^(NSDictionary<NSString *, id> *result) { resolve(result); }
                onCancel:^{ reject(@"cancelled", @"The patient cancelled", nil); }];
    [top presentViewController:vc animated:YES completion:nil];
  });
}

@end
