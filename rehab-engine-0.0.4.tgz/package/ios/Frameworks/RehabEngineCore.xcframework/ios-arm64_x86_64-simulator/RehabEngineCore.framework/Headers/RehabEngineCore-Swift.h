#if defined(__arm64__)
#include "RehabEngineCore-Swift-arm64.h"
#elif defined(__x86_64__)
#include "RehabEngineCore-Swift-x86_64.h"
#endif
