/**
 * - raise   舉手過頭: either arm up over the head (face the camera)
 * - lateral 側平舉: both arms out to shoulder height together (face the camera)
 * - curl    屈手肘: bend the elbow (side-on)
 * - wrist   手腕屈伸: bend the wrist up or down (side-on, forearm in view)
 * - pinch   拇指對食指: touch thumb tip to index tip (palm to the camera; hand tracking)
 */
export type RehabExercise = 'raise' | 'lateral' | 'curl' | 'wrist' | 'pinch';

export type RehabEngineRep = {
  /**
   * Furthest value reached in this rep, in the result's unit: the highest arm angle for raise and
   * lateral, the smallest joint angle for curl and wrist, the smallest thumb–index gap for pinch.
   */
  peak: number;
  /** From leaving the rest position to coming back. */
  durationMs: number;
  /** The patient's side that did the rep ('both' for lateral), or null when unknown. */
  side: 'left' | 'right' | 'both' | null;
};

export type RehabEngineResult = {
  exercise: RehabExercise;
  /**
   * 'degrees' for angle exercises; 'ratio' for pinch (thumb–index gap over palm length: about 1
   * with the hand open, near 0 when the tips touch).
   */
  unit: 'degrees' | 'ratio';
  reps: number;
  durationMs: number;
  /** Session start, milliseconds since 1970 (Date.now() style). */
  startedAt: number;
  /** Furthest value toward the target in the whole session, or null when never tracked. */
  best: number | null;
  /** One entry per counted rep, in order. */
  repDetails: RehabEngineRep[];
  /** Share of analysed frames (0...1) where the patient was clearly in view. */
  trackingRatio: number;
};

export type RehabEngineOptions = {
  /** Which exercise to run. Defaults to 'raise'; unknown values also fall back to 'raise'. */
  exercise?: RehabExercise;
};

export declare const RehabEngine: {
  /** Opens the native exercise screen full screen (iOS and Android); resolves when the patient taps 完成, rejects with code "cancelled" on 取消. */
  open(options?: RehabEngineOptions): Promise<RehabEngineResult>;
  /** True when the native module is built into the app. */
  isAvailable: boolean;
};
