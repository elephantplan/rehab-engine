// Thin JavaScript wrapper. All UI lives on the native side: Swift on iOS, Kotlin on Android.
const { NativeModules, Platform } = require('react-native');

const native = NativeModules.RehabEngine;

const RehabEngine = {
  isAvailable: native != null,
  open(options = {}) {
    if (native == null) {
      return Promise.reject(
        new Error(
          Platform.OS === 'ios'
            ? 'RehabEngine native module not found: run pod install and rebuild the app'
            : 'RehabEngine native module not found: rebuild the Android app',
        ),
      );
    }
    return native.open({ exercise: options.exercise ?? 'raise' });
  },
};

module.exports = { RehabEngine };
