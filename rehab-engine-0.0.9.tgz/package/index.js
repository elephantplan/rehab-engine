// Thin JavaScript wrapper. All UI lives on the native side: Swift on iOS, Kotlin on Android.
const { NativeModules, Platform } = require('react-native');

const native = NativeModules.RehabEngine;

function missing() {
  return Promise.reject(
    new Error(
      Platform.OS === 'ios'
        ? 'RehabEngine native module not found: run pod install and rebuild the app'
        : 'RehabEngine native module not found: rebuild the Android app',
    ),
  );
}

function readNativeVersion() {
  if (native == null) return null;
  if (typeof native.nativeVersion === 'string') return native.nativeVersion;
  const constants = typeof native.getConstants === 'function' ? native.getConstants() : null;
  return constants && typeof constants.nativeVersion === 'string' ? constants.nativeVersion : null;
}

const RehabEngine = {
  isAvailable: native != null,
  nativeVersion: readNativeVersion(),
  preload(options = {}) {
    if (native == null) return missing();
    return native.preload({ exercises: options.exercises ?? [], modelUrls: options.modelUrls ?? {} });
  },
  open(options = {}) {
    if (native == null) return missing();
    return native.open({ exercise: options.exercise ?? 'raise', modelUrls: options.modelUrls ?? {} });
  },
};

module.exports = { RehabEngine };
