// Tells React Native autolinking where the Android package class lives.
module.exports = {
  dependency: {
    platforms: {
      android: {
        sourceDir: './android',
        packageImportPath: 'import com.rehabengine.RehabEnginePackage;',
        packageInstance: 'new RehabEnginePackage()',
      },
    },
  },
};
