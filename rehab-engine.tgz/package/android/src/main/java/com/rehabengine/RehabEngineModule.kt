package com.rehabengine

import android.app.Activity
import android.content.Intent
import com.facebook.react.bridge.ActivityEventListener
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.ReadableMap
import com.rehabengine.core.RehabEngineActivity

/**
 * The thin React Native bridge: JS calls open(), this starts the native exercise screen and
 * resolves with its result. Same contract as the iOS bridge.
 */
class RehabEngineModule(context: ReactApplicationContext) :
  ReactContextBaseJavaModule(context), ActivityEventListener {

  companion object {
    const val NAME = "RehabEngine"
    private const val REQUEST_CODE = 0x5245 // "RE"
  }

  private var pending: Promise? = null

  init {
    context.addActivityEventListener(this)
  }

  override fun getName(): String = NAME

  @ReactMethod
  fun open(options: ReadableMap, promise: Promise) {
    val activity = reactApplicationContext.currentActivity
    if (activity == null) {
      promise.reject("no_activity", "No activity to present from")
      return
    }
    if (pending != null) {
      promise.reject("busy", "An exercise screen is already open")
      return
    }
    val exercise = if (options.hasKey("exercise")) options.getString("exercise") ?: "raise" else "raise"
    pending = promise
    activity.startActivityForResult(RehabEngineActivity.intent(activity, exercise), REQUEST_CODE)
  }

  override fun onActivityResult(activity: Activity, requestCode: Int, resultCode: Int, data: Intent?) {
    if (requestCode != REQUEST_CODE) return
    val promise = pending ?: return
    pending = null
    if (resultCode == Activity.RESULT_OK && data != null) {
      val result = Arguments.createMap()
      result.putString("exercise", data.getStringExtra(RehabEngineActivity.EXTRA_EXERCISE) ?: "raise")
      result.putInt("reps", data.getIntExtra(RehabEngineActivity.EXTRA_REPS, 0))
      result.putDouble("durationMs", data.getLongExtra(RehabEngineActivity.EXTRA_DURATION_MS, 0L).toDouble())
      promise.resolve(result)
    } else {
      promise.reject("cancelled", "The patient cancelled")
    }
  }

  override fun onNewIntent(intent: Intent) {}
}
