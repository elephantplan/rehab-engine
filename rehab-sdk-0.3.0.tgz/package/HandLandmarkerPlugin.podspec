Pod::Spec.new do |s|
  s.name         = 'HandLandmarkerPlugin'
  s.version      = '0.1.0'
  s.summary      = 'VisionCamera frame processor plugin running MediaPipe Hand Landmarker'
  s.homepage     = 'https://github.com/elephantplan/motion_app'
  s.license      = 'MIT'
  s.authors      = 'motion_app'
  s.platforms    = { :ios => '15.1' }
  s.source       = { :git => 'https://github.com/elephantplan/motion_app.git' }
  s.source_files = 'ios/**/*.{h,m,mm,swift}'
  s.swift_version = '5.0'
  s.pod_target_xcconfig = { 'DEFINES_MODULE' => 'YES' }

  # Same MediaPipe pod the pose library already brings in, so no extra download.
  s.dependency 'MediaPipeTasksVision', '~> 0.10.14'
  s.dependency 'VisionCamera'
  s.dependency 'React-Core'
end
