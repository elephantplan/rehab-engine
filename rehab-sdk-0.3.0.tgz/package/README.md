# rehab-sdk

A React Native SDK for home rehab exercises. It contains the **whole exercise screen**: front camera,
stick-figure skeleton or hand overlay, joint angles drawn on the body, a goniometer dial, rep counting
and coaching messages. Detection runs **on the phone** with Google MediaPipe. No video leaves the device.

The host app writes no exercise UI. It shows one component and receives numbers back.

```tsx
import { RehabSession, preloadModels, type RehabEngineResult } from 'rehab-sdk';

// When the mini app opens: download the AI models in the background (once; again only if a URL changes).
preloadModels(/* optional { pose, hand } URLs on your own server */);

<RehabSession
  exercise="raise"                              // raise | lateral | curl | wrist | pinch
  targetReps={10}                               // optional: shows "3 / 10" and finishes at 10
  onFinish={(result) => upload(result)}         // 完成 tapped or target reached
  onCancel={() => goBack()}                     // optional: shows 取消
  onRep={(soFar) => saveProgress(soFar)}        // optional: result so far after every rep
  modelUrls={{ pose: 'https://…', hand: 'https://…' }} // optional; defaults to Google's public files
/>
```

The result is **the same JSON as the native SDK (rehab-engine)**: reps, per-rep peak, start, range,
duration, hold time and compensations, attempts that missed the target, compensation counts, an angle
series every 200 ms, tracking ratio, targetReps and completed. See `src/engine/types.ts`. The rules,
thresholds and compensation checks are a port of the native SDK's, so the same movement gives the same numbers.

## Exercises

| id | Name | Model | Compensation checks |
|---|---|---|---|
| `raise` | 舉手過頭 | Pose | trunkLean, shoulderHike, elbowBent |
| `lateral` | 側平舉 | Pose | trunkLean, shoulderHike, elbowBent |
| `curl` | 屈手肘 | Pose | upperArmSwing, trunkLean |
| `wrist` | 手腕屈伸 | Pose | forearmMove |
| `pinch` | 拇指對食指 | Hand (iOS only for now) | fingersCurled |

## What the host app must provide

The SDK's native parts are built into the host binary. JavaScript (UI and rules) can be updated over the air.

1. **Peer dependencies** (see `package.json`): `react-native-vision-camera`, `react-native-worklets-core`,
   `react-native-svg`, `react-native-mediapipe-posedetection@0.4.0`, `expo-status-bar`.
2. **New Architecture** enabled, and iOS pods built as **static frameworks** (`expo-build-properties` → `ios.useFrameworks: "static"`).
3. **Config plugin**: add `"rehab-sdk"` to `app.json` → `plugins`. It fixes the MediaPipe pod's headers and
   bundles the model files.
4. **Babel**: `react-native-worklets-core/plugin` in `babel.config.js`.
5. **Fixes for the pose library** (it has packaging bugs with RN 0.76):
   - `react-native.config.js` pointing codegen at `react-native-mediapipe-posedetection` (see the example app).
   - `patches/react-native-mediapipe-posedetection+0.4.0.patch` applied with `patch-package`.
6. **`expo-file-system`** (peer dependency) for the model download.
7. Camera permission text (from the `react-native-vision-camera` config plugin).

## Packing a tarball for another app

```bash
cd packages/rehab-sdk
rm -f assets/models/*.task   # models are downloaded at run time; keep them out of the tarball
npm pack                     # → rehab-sdk-0.3.0.tgz
```

In the consuming app: `npm install /path/to/rehab-sdk-0.3.0.tgz`, then `npx expo prebuild --clean` and `pod install`.

## What is inside

| Path | Contents |
|---|---|
| `src/RehabSession.tsx` | The screen component and its public props |
| `src/engine/` | Exercise rules, compensations, rep counter and result (port of the native SDK, unit tested) |
| `src/pose/`, `src/hand/` | MediaPipe output conversion, smoothing, hand tracking hook |
| `src/components/`, `src/ui/` | Skeleton, hand overlay, dial, cue, rep counter, theme |
| `ios/`, `HandLandmarkerPlugin.podspec` | Native Swift plugin for MediaPipe Hand Landmarker |
| `app.plugin.js`, `plugin/` | Expo config plugin |
