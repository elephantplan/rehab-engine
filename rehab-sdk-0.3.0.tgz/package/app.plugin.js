// Expo config plugin for hosts using the rehab SDK. Add "rehab-sdk" to app.json plugins.
// It sets up the MediaPipe pose pod. Model files are downloaded at run time by default; pass
// { "bundleModels": true } to copy assets/models/ into the app instead (offline-first builds).
const path = require('path');
const withMediapipeHeaders = require('./plugin/withMediapipeHeaders');

module.exports = function withRehabSdk(config, { bundleModels = false, modelsPath } = {}) {
  config = withMediapipeHeaders(config);
  if (!bundleModels) return config;
  // The pose library's plugin copies every file in the folder into the iOS and Android projects.
  const mod = require('react-native-mediapipe-posedetection/app.plugin.js');
  const withPoseAssets = mod.default ?? mod;
  const models = modelsPath ?? path.relative(process.cwd(), path.join(__dirname, 'assets', 'models'));
  return withPoseAssets(config, { assetsPaths: [models.startsWith('.') ? models : `./${models}`] });
};
