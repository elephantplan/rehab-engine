#!/usr/bin/env bash
# Downloads the MediaPipe models into assets/models/ (copied into the app at prebuild):
#  - Pose Landmarker (full, float16): 33 body landmarks.
#    Swap "full" for "lite" in both places for a smaller, faster model on older phones.
#  - Hand Landmarker (float16): 21 points per hand, for the finger exercises.
set -euo pipefail
DIR="$(dirname "$0")/assets/models"
mkdir -p "$DIR"
curl -L -o "$DIR/pose_landmarker_full.task" \
  "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/latest/pose_landmarker_full.task"
curl -L -o "$DIR/hand_landmarker.task" \
  "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task"
echo "Saved to $DIR"
