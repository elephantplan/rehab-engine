#import <Foundation/Foundation.h>
#import <VisionCamera/FrameProcessorPlugin.h>
#import <VisionCamera/FrameProcessorPluginRegistry.h>
#import <VisionCamera/Frame.h>

// Registers the Swift plugin with VisionCamera as "handLandmarks".
// Uses an ObjC class with +load and a runtime class lookup, the same way
// react-native-mediapipe-posedetection registers its plugin (which works in this app's
// static-framework build), instead of VisionCamera's category-constructor macro.
@interface HandLandmarkerPluginLoader : NSObject
@end

@implementation HandLandmarkerPluginLoader

+ (void)load
{
  Class pluginClass = NSClassFromString(@"HandLandmarkerFrameProcessorPlugin");
  if (pluginClass == nil) {
    NSLog(@"[HandLandmarker] Swift class HandLandmarkerFrameProcessorPlugin not found; plugin not registered");
    return;
  }
  [FrameProcessorPluginRegistry addFrameProcessorPlugin:@"handLandmarks"
                                        withInitializer:^FrameProcessorPlugin *(VisionCameraProxyHolder *proxy,
                                                                                NSDictionary *options) {
    return [[pluginClass alloc] initWithProxy:proxy withOptions:options];
  }];
  NSLog(@"[HandLandmarker] registered frame processor plugin: handLandmarks");
}

@end
