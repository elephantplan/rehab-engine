import Foundation
import UIKit
import VisionCamera
import MediaPipeTasksVision

/// Runs MediaPipe Hand Landmarker on a camera frame and returns 21 points per hand.
/// Called synchronously from a JS frame processor: `plugin.call(frame, { orientation })`.
@objc(HandLandmarkerFrameProcessorPlugin)
public class HandLandmarkerFrameProcessorPlugin: FrameProcessorPlugin {
  private var landmarker: HandLandmarker?
  private var loadError: String?
  private var lastTimestamp = 0

  public override init(proxy: VisionCameraProxyHolder, options: [AnyHashable: Any]! = [:]) {
    super.init(proxy: proxy, options: options)
    let model = (options?["model"] as? String) ?? "hand_landmarker.task"
    // An absolute path is a model downloaded at run time; a bare name is looked up in the app bundle.
    let path: String
    if model.hasPrefix("/") {
      guard FileManager.default.fileExists(atPath: model) else {
        loadError = "Model file not found: \(model)"
        return
      }
      path = model
    } else {
      let url = URL(fileURLWithPath: model)
      guard let bundled = Bundle.main.path(forResource: url.deletingPathExtension().lastPathComponent,
                                           ofType: url.pathExtension) else {
        loadError = "Model \(model) not found in the app bundle"
        return
      }
      path = bundled
    }
    let o = HandLandmarkerOptions()
    o.baseOptions.modelAssetPath = path
    o.baseOptions.delegate = .GPU
    o.runningMode = .video
    o.numHands = (options?["numHands"] as? NSNumber)?.intValue ?? 1
    o.minHandDetectionConfidence = 0.5
    o.minHandPresenceConfidence = 0.5
    o.minTrackingConfidence = 0.5
    do {
      landmarker = try HandLandmarker(options: o)
    } catch {
      loadError = error.localizedDescription
    }
  }

  public override func callback(_ frame: Frame, withArguments arguments: [AnyHashable: Any]?) -> Any? {
    guard let landmarker else { return ["error": loadError ?? "Hand landmarker not created"] }
    let orientation = HandLandmarkerFrameProcessorPlugin.uiOrientation(arguments?["orientation"] as? String)
    guard let image = try? MPImage(sampleBuffer: frame.buffer, orientation: orientation) else { return nil }

    // Video mode needs strictly increasing timestamps.
    let now = Int(Date().timeIntervalSince1970 * 1000)
    lastTimestamp = max(now, lastTimestamp + 1)

    do {
      let result = try landmarker.detect(videoFrame: image, timestampInMilliseconds: lastTimestamp)
      let hands: [[[Double]]] = result.landmarks.map { hand in
        hand.map { [Double($0.x), Double($0.y), Double($0.z)] }
      }
      let handedness: [String] = result.handedness.map { $0.first?.categoryName ?? "" }
      return [
        "width": Double(image.width),
        "height": Double(image.height),
        "hands": hands,
        "handedness": handedness,
      ]
    } catch {
      return ["error": error.localizedDescription]
    }
  }

  /// Same mapping as react-native-mediapipe-posedetection, so both share one coordinate system.
  static func uiOrientation(_ orientation: String?) -> UIImage.Orientation {
    switch orientation {
    case "portrait-upside-down": return .down
    case "landscape-left": return .right
    case "landscape-right": return .left
    default: return .up
    }
  }
}
