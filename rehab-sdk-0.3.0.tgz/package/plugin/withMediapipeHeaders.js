// react-native-mediapipe-posedetection imports its codegen header as "MediapipePosedetectionSpec.h",
// but React Native 0.76 puts it at build/generated/ios/MediapipePosedetectionSpec/. Adds that folder
// to the pod's header search paths so the import resolves.
const fs = require('fs');
const path = require('path');
const { withDangerousMod } = require('expo/config-plugins');

const MARKER = '# withMediapipeHeaders';

module.exports = function withMediapipeHeaders(config) {
  return withDangerousMod(config, [
    'ios',
    (cfg) => {
      const podfile = path.join(cfg.modRequest.platformProjectRoot, 'Podfile');
      let contents = fs.readFileSync(podfile, 'utf8');
      if (!contents.includes(MARKER)) {
        const snippet = [
          `    ${MARKER}`,
          '    installer.pods_project.targets.each do |t|',
          "      next unless t.name == 'MediapipePosedetection'",
          '      t.build_configurations.each do |c|',
          "        extra = ['\"${PODS_ROOT}/../build/generated/ios\"', '\"${PODS_ROOT}/../build/generated/ios/MediapipePosedetectionSpec\"']",
          "        c.build_settings['HEADER_SEARCH_PATHS'] = ['$(inherited)'] + extra",
          // The .mm imports the Swift half of the pod as "MediapipePosedetection-Swift.h".
          "        c.build_settings['DEFINES_MODULE'] = 'YES'",
          "        c.build_settings['SWIFT_OBJC_INTERFACE_HEADER_NAME'] = 'MediapipePosedetection-Swift.h'",
          '      end',
          '    end',
        ].join('\n');
        const hook = /post_install do \|installer\|\n/;
        if (!hook.test(contents)) throw new Error('withMediapipeHeaders: post_install hook not found in Podfile');
        contents = contents.replace(hook, (m) => `${m}${snippet}\n`);
        fs.writeFileSync(podfile, contents);
      }
      return cfg;
    },
  ]);
};
