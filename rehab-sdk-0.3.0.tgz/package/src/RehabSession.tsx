import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Platform, Pressable, SafeAreaView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Camera, useCameraDevice, useCameraFormat, useCameraPermission, type Orientation } from 'react-native-vision-camera';
import type { LayoutChangeEvent } from 'react-native';
import type { PoseDetectionResultBundle, ViewCoordinator } from 'react-native-mediapipe-posedetection';
import { Keypoint } from './pose/types';
import { Exercise, MIN_VISIBILITY, type Reading } from './engine/exercises';
import { Session } from './engine/session';
import type { RehabEngineResult, RehabExercise } from './engine/types';
import { SkeletonOverlay } from './components/SkeletonOverlay';
import { KeypointSmoother } from './pose/smoothing';
import { imageToScreen } from './pose/mediapipe';
import { mediapipe, mediapipeLoadError } from './pose/loadMediapipe';
import { colors, type } from './ui/theme';
import { Goniometer } from './ui/Goniometer';
import { CueBanner } from './ui/CueBanner';
import { RepCount } from './ui/RepCount';
import { PinchMeter } from './ui/PinchMeter';
import { HandOverlay } from './components/HandOverlay';
import { HAND_NAMES, HandPoint } from './hand/types';
import { HandResult, useHandLandmarks } from './hand/useHandLandmarks';
import { DEFAULT_MODEL_URLS, preloadModels, type ModelPaths, type ModelUrls } from './models/modelStore';

// How long a coaching message stays on screen after it fires.
const CUE_HOLD_MS = 1500;
// Shown angles only change when they move by at least this much, so the numbers stop flickering.
const ANGLE_STEP = 2;

/** Same options as the native SDK's open(): one exercise per screen. */
export type RehabSessionProps = {
  /** Which exercise to run. Defaults to 'raise'; unknown values also fall back to 'raise'. */
  exercise?: RehabExercise;
  /** Reps prescribed: shows "3 / 10" and finishes by itself at the target. 0 or unset: no target. */
  targetReps?: number;
  /** Called with the result when the patient taps 完成 or reaches targetReps. Same JSON as the native SDK. */
  onFinish: (result: RehabEngineResult) => void;
  /** Called when the patient taps 取消 (the native SDK rejects with 'cancelled'). The button shows when set. */
  onCancel?: () => void;
  /** Called after every counted rep with the result so far, e.g. to save progress between rounds. */
  onRep?: (soFar: RehabEngineResult) => void;
  /** Where to download the model files from. Defaults to Google's public files (DEFAULT_MODEL_URLS). */
  modelUrls?: ModelUrls;
  /** Use model files bundled into the app (plugin option bundleModels) instead of downloading. */
  bundledModels?: boolean;
};

// File names copied into the app by the plugin's bundleModels option (see download-model.sh).
const BUNDLED: ModelPaths = { pose: 'pose_landmarker_full.task', hand: 'hand_landmarker.task' };

/**
 * The whole exercise screen: camera, skeleton or hand overlay, angle readouts, rep count and
 * coaching. A host app renders this full screen and gets results through the callbacks.
 */
export function RehabSession(props: RehabSessionProps) {
  if (!mediapipe) return <Centered text={`MediaPipe 載入失敗：${mediapipeLoadError}`} />;
  return (
    <ErrorBoundary>
      <ModelGate {...props} />
    </ErrorBoundary>
  );
}

/** Makes sure the model files are on the phone before the camera screen starts. */
function ModelGate(props: RehabSessionProps) {
  const [paths, setPaths] = useState<ModelPaths | null>(props.bundledModels ? BUNDLED : null);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);
  const urls = props.modelUrls;
  useEffect(() => {
    if (props.bundledModels) return;
    let alive = true;
    setError(null);
    preloadModels(urls, (f) => alive && setProgress(f))
      .then((p) => alive && setPaths(p))
      .catch((e) => alive && setError(e instanceof Error ? e.message : String(e)));
    return () => {
      alive = false;
    };
  }, [urls?.pose, urls?.hand, attempt, props.bundledModels]);
  if (error) {
    return (
      <View style={[styles.root, styles.center]}>
        <Text style={styles.text}>{`AI model 下載失敗，請檢查網絡。\n${error}`}</Text>
        <Pressable onPress={() => setAttempt((n) => n + 1)}>
          <Text style={styles.text}>重試</Text>
        </Pressable>
      </View>
    );
  }
  if (!paths) return <Centered text={`下載 AI model 中… ${Math.round(progress * 100)}%`} />;
  const modelSource = (kind: 'pose' | 'hand') => (props.bundledModels ? 'bundled' : urls?.[kind] ?? DEFAULT_MODEL_URLS[kind]);
  return <PoseApp {...props} modelPaths={paths} modelSource={modelSource} />;
}

/** Shows a render error on screen instead of closing the app. */
class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { error: string | null }> {
  state = { error: null as string | null };
  static getDerivedStateFromError(e: unknown) {
    return { error: e instanceof Error ? `${e.message}\n${e.stack ?? ''}` : String(e) };
  }
  render() {
    return this.state.error ? <Centered text={`出錯：${this.state.error}`} /> : this.props.children;
  }
}

function PoseApp({ exercise: exerciseId, targetReps = 0, onRep, onFinish, onCancel, modelPaths, modelSource }: RehabSessionProps & { modelPaths: ModelPaths; modelSource: (kind: 'pose' | 'hand') => string }) {
  const { Delegate, RunningMode, usePoseDetection } = mediapipe!;
  const { hasPermission, requestPermission } = useCameraPermission();
  const device = useCameraDevice('front');
  // ~720p is plenty for pose detection and keeps older phones responsive.
  const format = useCameraFormat(device, [{ videoResolution: { width: 1280, height: 720 } }, { fps: 30 }]);
  const { width, height } = useWindowDimensions();
  // The camera takes most of the screen; the panel overlaps its lower edge.
  const previewHeight = Math.round(height * 0.64);

  // One session per screen: rules, counting, series and the result, the same as the native SDK.
  const session = useRef<Session | null>(null);
  if (session.current == null) {
    const ex = new Exercise(exerciseId);
    session.current = new Session(ex.id, Math.max(0, Math.floor(targetReps)), modelSource(ex.usesHand ? 'hand' : 'pose'));
  }
  const s = session.current;
  const exercise = s.exercise;
  const handMode = exercise.usesHand;

  const [points, setPoints] = useState<Keypoint[]>([]);
  const [reading, setReading] = useState<Reading | null>(null);
  const [, setTick] = useState(0);
  const [fps, setFps] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [frameCue, setFrameCue] = useState<string | null>(null);
  const closing = useRef(false);
  const frameTimes = useRef<number[]>([]);
  const screenSmoother = useRef(new KeypointSmoother({ minCutoff: 0.6, beta: 0.02, dCutoff: 1.0 })).current;

  useEffect(() => {
    if (!hasPermission) requestPermission();
  }, [hasPermission, requestPermission]);

  const countFrame = useCallback((now: number) => {
    const times = frameTimes.current;
    times.push(now);
    while (times.length && now - times[0] > 1000) times.shift();
    setFps(times.length);
  }, []);

  const finish = useCallback(() => {
    if (closing.current) return;
    closing.current = true;
    onFinish(s.result());
  }, [onFinish, s]);

  // Every frame goes through the session, then the screen updates from it.
  const apply = useCallback((r: Reading, usable: boolean, now: number) => {
    if (closing.current) return;
    const before = s.counter.reps;
    s.step(r, usable, now);
    setReading(r);
    setFrameCue(s.counter.cue ?? r.cue);
    setTick((t) => t + 1);
    countFrame(now);
    if (s.counter.reps > before) onRep?.(s.result(now));
    // Target reached: say so, then close by itself with the result.
    if (s.completed) {
      setFrameCue('完成目標！做得好');
      closing.current = true;
      setTimeout(() => onFinish(s.result()), 1200);
    }
  }, [s, countFrame, onRep, onFinish]);

  const onResults = useCallback((bundle: PoseDetectionResultBundle, vc: ViewCoordinator) => {
    const now = Date.now();
    const image = bundle.results[0]?.landmarks[0];
    if (!image) {
      // Nobody in view still counts as a frame, so a lost patient ends the movement.
      setPoints([]);
      apply(exercise.readPose([], s.trackedSide), false, now);
      return;
    }
    const frame = vc.getFrameDims(bundle);
    const screen = screenSmoother.smooth(imageToScreen(image, (p) => vc.convertPoint(frame, p)), now);
    const usable = exercise.required.every((n) => (screen.find((k) => k.name === n)?.score ?? 0) >= MIN_VISIBILITY);
    setPoints(usable ? screen : []);
    apply(exercise.readPose(usable ? screen : [], s.trackedSide), usable, now);
  }, [screenSmoother, exercise, s, apply]);

  const callbacks = useMemo(() => ({ onResults, onError: (e: { message: string }) => setError(e.message) }), [onResults]);
  const pose = usePoseDetection(callbacks, RunningMode.LIVE_STREAM, modelPaths.pose, {
    numPoses: 1,
    delegate: Delegate.GPU,
    // The library's per-platform default: iOS front-camera frames already match the mirrored
    // preview, Android's need flipping. Forcing a mirror on iOS drew the skeleton on the wrong arm.
    mirrorMode: Platform.OS === 'android' ? 'mirror-front-only' : 'no-mirror',
  });

  // Hand tracking: our own MediaPipe Hand Landmarker plugin, converted to screen pixels with the
  // pose library's view coordinator so both overlays line up the same way.
  const [viewSize, setViewSize] = useState({ width: 1, height: 1 });
  const [hand, setHand] = useState<HandPoint[]>([]);
  const coordinator = useRef<{ key: string; vc: ViewCoordinator } | null>(null);
  const onHand = useCallback((r: HandResult, frameOrientation: Orientation) => {
    if (r.error) {
      setError(r.error);
      return;
    }
    const key = `${frameOrientation}-${viewSize.width}x${viewSize.height}`;
    if (coordinator.current?.key !== key) {
      const vc = new mediapipe!.BaseViewCoordinator(viewSize, Platform.OS === 'android', frameOrientation, 'portrait', 'cover');
      coordinator.current = { key, vc };
    }
    const vc = coordinator.current.vc;
    const frame = vc.getFrameDims({ inputImageWidth: r.width, inputImageHeight: r.height, inferenceTime: 0 });
    const first = r.hands[0];
    const pts = first
      ? HAND_NAMES.map((name, i) => {
          const p = vc.convertPoint(frame, { x: first[i][0], y: first[i][1] });
          return { name, x: p.x, y: p.y };
        })
      : null;
    setHand(pts ?? []);
    // MediaPipe names hands as seen in a mirrored picture; like the native SDK, its "Left" is the patient's right.
    const label = r.handedness?.[0]?.toLowerCase();
    const side = label === 'left' ? 'right' : label === 'right' ? 'left' : null;
    apply(exercise.readHand(pts, side), pts != null, Date.now());
  }, [viewSize, exercise, apply]);
  const { frameProcessor: handFrameProcessor, available: handAvailable } = useHandLandmarks(onHand, modelPaths.hand);
  const onCameraLayout = useCallback((e: LayoutChangeEvent) => {
    pose.cameraViewLayoutChangeHandler(e);
    setViewSize({ width: e.nativeEvent.layout.width, height: e.nativeEvent.layout.height });
  }, [pose]);

  useEffect(() => {
    if (device) pose.cameraDeviceChangeHandler(device);
  }, [device, pose]);
  useEffect(() => {
    pose.resizeModeChangeHandler('cover');
  }, [pose]);

  // Say so on screen when the native hand plugin did not load, instead of hiding the exercise.
  const shownCue = handMode && !handAvailable
    ? '手部偵測未載入：native plugin 冇 build 入 app（Android 暫時未支援）'
    : frameCue;
  const cue = useStickyCue(shownCue);
  const value = s.counter.value;
  const angle = useSteadyAngle(handMode ? null : value);
  const title = exercise.title(s.trackedSide === 'both' ? null : s.trackedSide);

  if (!hasPermission) return <Centered text="需要鏡頭權限" />;
  if (device == null) return <Centered text="搵唔到前鏡頭" />;
  if (error) return <Centered text={`偵測出錯：${error}`} />;

  return (
    <View style={styles.root}>
      <StatusBar style="light" />
      <View style={{ width, height: previewHeight }}>
        <Camera
          style={StyleSheet.absoluteFill}
          device={device}
          format={format}
          isActive
          resizeMode="cover"
          pixelFormat="rgb"
          frameProcessor={handMode ? handFrameProcessor : pose.frameProcessor}
          onLayout={onCameraLayout}
          onOutputOrientationChanged={pose.cameraOrientationChangedHandler}
        />
        {handMode ? (
          <HandOverlay points={hand} width={width} height={previewHeight} touching={exercise.pinchProgress(value) >= 1} />
        ) : (
          <SkeletonOverlay points={points} width={width} height={previewHeight} focus={reading?.focus ?? []} measures={reading?.measures ?? []} />
        )}
        <SafeAreaView style={styles.topBar}>
          <Text style={[type.title, styles.topTitle]} numberOfLines={1}>{title}</Text>
        </SafeAreaView>
        <CueBanner cue={cue} />
      </View>

      <View style={styles.panel}>
        <Text style={[type.body, styles.instruction]}>{exercise.instruction}</Text>
        <View style={styles.readouts}>
          <RepCount reps={s.counter.reps} target={s.targetReps > 0 ? s.targetReps : null} />
          {exercise.gauge && <Goniometer gauge={exercise.gauge} value={angle} />}
          {handMode && <PinchMeter progress={exercise.pinchProgress(value)} label="拇指 ↔ 食指" />}
        </View>
        <View style={styles.footer}>
          <View style={[styles.dot, { backgroundColor: fps >= 10 ? colors.sage : colors.amber }]} />
          <Text style={[type.label, styles.meta]}>{`本機分析・${fps} fps`}</Text>
          {onCancel && (
            <Pressable accessibilityRole="button" onPress={() => { closing.current = true; onCancel(); }} style={({ pressed }) => [styles.cancel, pressed && styles.pressed]}>
              <Text style={[type.body, styles.cancelText]}>取消</Text>
            </Pressable>
          )}
          <Pressable accessibilityRole="button" onPress={finish} style={({ pressed }) => [styles.finish, pressed && styles.pressed]}>
            <Text style={[type.body, styles.finishText]}>完成</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

/** Keeps the last coaching message up for CUE_HOLD_MS instead of flashing it for one frame. */
function useStickyCue(cue: string | null) {
  const [shown, setShown] = useState<string | null>(null);
  useEffect(() => {
    if (cue != null) setShown(cue);
  }, [cue]);
  useEffect(() => {
    if (shown == null) return;
    const t = setTimeout(() => setShown(null), CUE_HOLD_MS);
    return () => clearTimeout(t);
  }, [shown, cue]);
  return cue ?? shown;
}

/** Angle that ignores changes smaller than ANGLE_STEP, so readouts do not flicker. */
function useSteadyAngle(value: number | null) {
  const [shown, setShown] = useState<number | null>(value);
  useEffect(() => {
    if (value == null || shown == null || Math.abs(value - shown) >= ANGLE_STEP) setShown(value);
  }, [value, shown]);
  return shown;
}

function Centered({ text }: { text: string }) {
  return (
    <View style={[styles.root, styles.center]}>
      <Text style={styles.text}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.stage },
  center: { alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: colors.porcelain },
  text: { ...type.body, color: colors.ink, textAlign: 'center' },
  topBar: { position: 'absolute', top: 0, left: 0, right: 0, backgroundColor: '#5BB8E4' },
  topTitle: { color: colors.ink, textAlign: 'center', paddingVertical: 12, paddingHorizontal: 16 },
  pressed: { opacity: 0.75 },
  panel: {
    flex: 1, marginTop: -28, backgroundColor: colors.porcelain,
    borderTopLeftRadius: 28, borderTopRightRadius: 28,
    paddingHorizontal: 24, paddingTop: 22, paddingBottom: 28, gap: 14,
  },
  instruction: { color: colors.slate },
  readouts: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
  footer: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 'auto' },
  dot: { width: 8, height: 8, borderRadius: 4 },
  meta: { color: colors.slate, flex: 1 },
  cancel: { borderRadius: 999, paddingVertical: 10, paddingHorizontal: 18, borderWidth: 1, borderColor: colors.hairline },
  cancelText: { color: colors.ink },
  finish: { backgroundColor: colors.ink, borderRadius: 999, paddingVertical: 10, paddingHorizontal: 22 },
  finishText: { color: colors.card, fontWeight: '700' },
});
