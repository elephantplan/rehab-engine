import { Keypoint, KeypointName } from '../pose/types';

export const MIN_SCORE = 0.5;

type Point = { x: number; y: number; z?: number };

/** Angle at vertex b formed by a-b-c, in degrees (0..180). Uses z when all three points have it. */
export function angleAt(a: Point, b: Point, c: Point): number {
  const useZ = a.z != null && b.z != null && c.z != null;
  const u = [a.x - b.x, a.y - b.y, useZ ? a.z! - b.z! : 0];
  const v = [c.x - b.x, c.y - b.y, useZ ? c.z! - b.z! : 0];
  const dot = u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
  const len = Math.hypot(u[0], u[1], u[2]) * Math.hypot(v[0], v[1], v[2]);
  if (len === 0) return 0;
  return (Math.acos(Math.min(1, Math.max(-1, dot / len))) * 180) / Math.PI;
}

export function getKeypoint(kps: Keypoint[], name: KeypointName): Keypoint | undefined {
  const kp = kps.find((k) => k.name === name);
  return kp && kp.score >= MIN_SCORE ? kp : undefined;
}

/** Point halfway between two keypoints (any confidence), or undefined if either is missing. */
export function midpoint(kps: Keypoint[], a: KeypointName, b: KeypointName): Point | undefined {
  const p = kps.find((k) => k.name === a);
  const q = kps.find((k) => k.name === b);
  if (!p || !q) return undefined;
  const z = p.z != null && q.z != null ? (p.z + q.z) / 2 : undefined;
  return { x: (p.x + q.x) / 2, y: (p.y + q.y) / 2, z };
}
