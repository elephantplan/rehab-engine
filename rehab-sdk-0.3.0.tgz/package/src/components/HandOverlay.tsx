import React from 'react';
import { StyleSheet } from 'react-native';
import Svg, { Circle, Line } from 'react-native-svg';
import { HAND_BONES, HandName, HandPoint } from '../hand/types';
import { colors } from '../ui/theme';

type Props = { points: HandPoint[]; width: number; height: number; touching: boolean };

/** The 21-point hand, with the thumb and index tips and the line between them highlighted. */
export function HandOverlay({ points, width, height, touching }: Props) {
  const at = new Map<HandName, HandPoint>(points.map((p) => [p.name, p]));
  const thumb = at.get('thumbTip');
  const index = at.get('indexTip');
  const pinch = touching ? colors.sage : colors.cobalt;
  return (
    <Svg style={StyleSheet.absoluteFill} width={width} height={height}>
      {HAND_BONES.map(([a, b]) => {
        const p = at.get(a);
        const q = at.get(b);
        if (!p || !q) return null;
        return (
          <React.Fragment key={`${a}-${b}`}>
            <Line x1={p.x} y1={p.y} x2={q.x} y2={q.y} stroke="rgba(11,16,22,0.35)" strokeWidth={7} strokeLinecap="round" />
            <Line x1={p.x} y1={p.y} x2={q.x} y2={q.y} stroke={colors.bone} strokeWidth={2.5} strokeLinecap="round" />
          </React.Fragment>
        );
      })}
      {thumb && index && (
        <Line x1={thumb.x} y1={thumb.y} x2={index.x} y2={index.y} stroke={pinch} strokeWidth={4} strokeDasharray="6 6" strokeLinecap="round" />
      )}
      {points.map((p) =>
        p.name === 'thumbTip' || p.name === 'indexTip' ? (
          <React.Fragment key={p.name}>
            <Circle cx={p.x} cy={p.y} r={14} fill={touching ? 'rgba(46,158,107,0.3)' : 'rgba(47,91,234,0.25)'} />
            <Circle cx={p.x} cy={p.y} r={7} fill={pinch} stroke={colors.bone} strokeWidth={2.5} />
          </React.Fragment>
        ) : (
          <Circle key={p.name} cx={p.x} cy={p.y} r={3.5} fill={colors.bone} stroke="rgba(11,16,22,0.45)" strokeWidth={1} />
        ),
      )}
    </Svg>
  );
}
