import React from 'react';
import { StyleSheet } from 'react-native';
import Svg, { Circle, G, Line, Path, Rect, Text as SvgText } from 'react-native-svg';
import { MIN_VISIBILITY as MIN_SCORE } from '../engine/exercises';
import { Keypoint, KeypointName } from '../pose/types';
import { colors } from '../ui/theme';
import type { BodyRef, Measure } from '../engine/exercises';

const BONES: [KeypointName, KeypointName][] = [
  ['leftShoulder', 'rightShoulder'],
  ['leftShoulder', 'leftElbow'], ['leftElbow', 'leftWrist'],
  ['rightShoulder', 'rightElbow'], ['rightElbow', 'rightWrist'],
  ['leftWrist', 'leftIndex'], ['leftWrist', 'leftPinky'], ['leftIndex', 'leftPinky'], ['leftWrist', 'leftThumb'],
  ['rightWrist', 'rightIndex'], ['rightWrist', 'rightPinky'], ['rightIndex', 'rightPinky'], ['rightWrist', 'rightThumb'],
  ['leftShoulder', 'leftHip'], ['rightShoulder', 'rightHip'], ['leftHip', 'rightHip'],
  ['leftHip', 'leftKnee'], ['leftKnee', 'leftAnkle'], ['leftAnkle', 'leftHeel'], ['leftHeel', 'leftFootIndex'],
  ['rightHip', 'rightKnee'], ['rightKnee', 'rightAnkle'], ['rightAnkle', 'rightHeel'], ['rightHeel', 'rightFootIndex'],
];

// Face points other than the nose only add clutter for exercise feedback.
const HIDDEN = new Set<KeypointName>([
  'leftEyeInner', 'leftEye', 'leftEyeOuter', 'rightEyeInner', 'rightEye', 'rightEyeOuter',
  'leftEar', 'rightEar', 'mouthLeft', 'mouthRight',
]);

/** `points` are already in screen pixels inside a width × height box. `focus` joints are highlighted. */
type Props = { points: Keypoint[]; width: number; height: number; focus?: KeypointName[]; measures?: Measure[] };

type P = { x: number; y: number };
const ARC_RADIUS = 38;
const DOWN_LENGTH = 80;

/** Screen position of a body reference, or null when the model cannot see it well enough. */
function resolve(ref: BodyRef, vertex: P, byName: Map<KeypointName, Keypoint>, all: Keypoint[]): P | null {
  if (ref === 'down') {
    // "Down the body": from mid-shoulders toward mid-hips when the hips are seen, as the analysis does.
    const find = (n: KeypointName) => all.find((k) => k.name === n && k.score >= MIN_SCORE);
    const [ls, rs, lh, rh] = (['leftShoulder', 'rightShoulder', 'leftHip', 'rightHip'] as const).map(find);
    let d = { x: 0, y: 1 };
    if (ls && rs && lh && rh) {
      const v = { x: (lh.x + rh.x - ls.x - rs.x) / 2, y: (lh.y + rh.y - ls.y - rs.y) / 2 };
      const len = Math.hypot(v.x, v.y);
      if (len > 0) d = { x: v.x / len, y: v.y / len };
    }
    return { x: vertex.x + d.x * DOWN_LENGTH, y: vertex.y + d.y * DOWN_LENGTH };
  }
  const names = Array.isArray(ref) ? ref : [ref];
  const pts = names.map((n) => byName.get(n));
  if (pts.some((p) => !p)) return null;
  return { x: pts.reduce((t, p) => t + p!.x, 0) / pts.length, y: pts.reduce((t, p) => t + p!.y, 0) / pts.length };
}

/** The arc and label for one measured angle, drawn at its joint. */
function AngleMark({ m, byName, all }: { m: Measure; byName: Map<KeypointName, Keypoint>; all: Keypoint[] }) {
  const v = byName.get(m.vertex);
  if (!v || m.value == null) return null;
  const a = resolve(m.a, v, byName, all);
  const c = resolve(m.c, v, byName, all);
  if (!a || !c) return null;
  const unit = (p: P) => {
    const len = Math.hypot(p.x - v.x, p.y - v.y) || 1;
    return { x: (p.x - v.x) / len, y: (p.y - v.y) / len };
  };
  const ua = unit(a);
  const uc = unit(c);
  const p1 = { x: v.x + ua.x * ARC_RADIUS, y: v.y + ua.y * ARC_RADIUS };
  const p2 = { x: v.x + uc.x * ARC_RADIUS, y: v.y + uc.y * ARC_RADIUS };
  // Sweep the short way round: clockwise on screen when the cross product is positive.
  const sweep = ua.x * uc.y - ua.y * uc.x > 0 ? 1 : 0;
  let bis = { x: ua.x + uc.x, y: ua.y + uc.y };
  const bl = Math.hypot(bis.x, bis.y);
  bis = bl < 1e-3 ? { x: -ua.y, y: ua.x } : { x: bis.x / bl, y: bis.y / bl };
  const label = `${Math.round(m.value)}°`;
  const lw = label.length * 11 + 16;
  const lx = v.x + bis.x * (ARC_RADIUS + 26);
  const ly = v.y + bis.y * (ARC_RADIUS + 26);
  return (
    <G>
      <Path
        d={`M ${v.x} ${v.y} L ${p1.x} ${p1.y} A ${ARC_RADIUS} ${ARC_RADIUS} 0 0 ${sweep} ${p2.x} ${p2.y} Z`}
        fill="rgba(47,91,234,0.28)" stroke={colors.cobalt} strokeWidth={2.5}
      />
      <Rect x={lx - lw / 2} y={ly - 14} width={lw} height={28} rx={14} fill={colors.cobalt} />
      <SvgText x={lx} y={ly + 6} fill={colors.bone} fontSize={17} fontWeight="700" textAnchor="middle">{label}</SvgText>
    </G>
  );
}

export function SkeletonOverlay({ points, width, height, focus = [], measures = [] }: Props) {
  const focused = new Set(focus);
  const byName = new Map(points.filter((k) => k.score >= MIN_SCORE).map((k) => [k.name, k]));
  return (
    <Svg style={StyleSheet.absoluteFill} width={width} height={height}>
      {BONES.map(([a, b]) => {
        const p = byName.get(a);
        const q = byName.get(b);
        if (!p || !q) return null;
        const hot = focused.has(a) || focused.has(b);
        return (
          <React.Fragment key={`${a}-${b}`}>
            {/* A soft halo under each bone keeps it readable on busy backgrounds. */}
            <Line x1={p.x} y1={p.y} x2={q.x} y2={q.y} stroke="rgba(11,16,22,0.35)" strokeWidth={9} strokeLinecap="round" />
            <Line x1={p.x} y1={p.y} x2={q.x} y2={q.y} stroke={hot ? colors.cobaltSoft : colors.bone} strokeWidth={hot ? 5 : 3.5} strokeLinecap="round" />
          </React.Fragment>
        );
      })}
      {[...byName.values()].filter((k) => !HIDDEN.has(k.name)).map((k) => (
        focused.has(k.name) ? (
          <React.Fragment key={k.name}>
            <Circle cx={k.x} cy={k.y} r={16} fill="rgba(47,91,234,0.25)" />
            <Circle cx={k.x} cy={k.y} r={8} fill={colors.cobalt} stroke={colors.bone} strokeWidth={3} />
          </React.Fragment>
        ) : (
          <Circle key={k.name} cx={k.x} cy={k.y} r={4.5} fill={colors.bone} stroke="rgba(11,16,22,0.45)" strokeWidth={1.5} />
        )
      ))}
      {measures.map((m) => (
        <AngleMark key={m.vertex} m={m} byName={byName} all={points} />
      ))}
    </Svg>
  );
}
