import { Exercise, angle } from './exercises';
import { RepCounter } from './repCounter';
import { Session } from './session';
import { KEYPOINT_NAMES, type Keypoint, type KeypointName } from '../pose/types';
import { HAND_NAMES, type HandPoint } from '../hand/types';

const RAISE = new Exercise('raise').config;

/** Feeds values one frame apart (100 ms) and returns the counter. */
function run(values: (number | null)[], comps: string[][] = []) {
  const c = new RepCounter(RAISE, 0);
  values.forEach((v, i) => c.step(v, 'right', i * 100, (comps[i] ?? []) as never));
  return c;
}

describe('RepCounter (same rules as the native SDK)', () => {
  it('counts a rep after 3 frames in the target and 3 back at rest, with its detail', () => {
    const c = run([30, 30, 90, 160, 165, 170, 168, 90, 40, 35, 30]);
    expect(c.reps).toBe(1);
    const r = c.repDetails[0];
    expect(r.peak).toBe(170);
    expect(r.start).toBe(30);
    expect(r.atMs).toBe(200); // the movement began on the third frame
    expect(r.holdMs).toBe(300); // frames 3..6 in the target zone
    expect(r.side).toBe('right');
    expect(c.best).toBe(170);
  });

  it('records an attempt that did not reach the target', () => {
    const c = run([30, 100, 110, 100, 40, 30]);
    expect(c.reps).toBe(0);
    expect(c.attempts).toHaveLength(1);
    expect(c.attempts[0].peak).toBe(110);
    expect(c.cue).toBeNull(); // cue was given on the frame it came back
  });

  it('keeps a compensation only when it lasts 3 frames within a movement', () => {
    const v = [30, 160, 165, 170, 168, 40, 35, 30];
    const once = run(v, [[], ['trunkLean'], [], [], [], [], [], []]);
    expect(once.repDetails[0].compensations).toEqual([]);
    const lasting = run(v, [[], ['trunkLean'], ['trunkLean'], ['trunkLean'], [], [], [], []]);
    expect(lasting.repDetails[0].compensations).toEqual(['trunkLean']);
  });

  it('drops the movement after 4 frames without a reading', () => {
    const c = run([30, 160, 165, 170, null, null, null, null, 30, 30, 30]);
    expect(c.reps).toBe(0);
  });

  it('flags a hiked shoulder against the gap measured at rest', () => {
    const c = new RepCounter(RAISE, 0);
    [30, 30, 30].forEach((v, i) => c.step(v, 'right', i * 100, [], 1.0));
    [80, 90, 100, 110].forEach((v, i) => c.step(v, 'right', 300 + i * 100, [], 0.5));
    [40, 35, 30].forEach((v, i) => c.step(v, 'right', 700 + i * 100, [], 1.0));
    expect(c.attempts[0].compensations).toEqual(['shoulderHike']);
  });
});

/** Screen points (y down) for a person facing the camera; overrides move single joints. */
function body(over: Partial<Record<KeypointName, [number, number]>> = {}): Keypoint[] {
  const base: Partial<Record<KeypointName, [number, number]>> = {
    nose: [200, 100], leftEar: [220, 95], rightEar: [180, 95],
    leftShoulder: [250, 200], rightShoulder: [150, 200],
    leftElbow: [250, 300], rightElbow: [150, 300], leftWrist: [250, 400], rightWrist: [150, 400],
    leftHip: [240, 450], rightHip: [160, 450],
    ...over,
  };
  return KEYPOINT_NAMES.map((name) => {
    const p = base[name];
    return { name, x: p?.[0] ?? 0, y: p?.[1] ?? 0, score: p ? 0.9 : 0 };
  });
}

describe('Exercise readings', () => {
  it('raise: arm straight up reads about 180°, hanging about 0°', () => {
    const ex = new Exercise('raise');
    expect(ex.readPose(body(), null).value).toBeCloseTo(0, 0);
    const up = ex.readPose(body({ rightElbow: [150, 100], rightWrist: [150, 0] }), null);
    expect(up.value).toBeCloseTo(180, 0);
    expect(up.side).toBe('right');
    expect(up.compensations).toEqual([]);
  });

  it('raise: needs nose and both shoulders', () => {
    const pts = body().map((k) => (k.name === 'nose' ? { ...k, score: 0 } : k));
    expect(new Exercise('raise').readPose(pts, null).value).toBeNull();
  });

  it('raise: flags a bent elbow and a leaning trunk', () => {
    const r = new Exercise('raise').readPose(
      body({ rightElbow: [200, 150], rightWrist: [250, 80], leftShoulder: [350, 200], rightShoulder: [250, 200] }),
      null,
    );
    expect(r.compensations).toEqual(expect.arrayContaining(['elbowBent', 'trunkLean']));
  });

  it('curl: elbow angle from the shoulder-elbow-wrist points', () => {
    const r = new Exercise('curl').readPose(body({ rightWrist: [250, 300] }), null);
    expect(r.side).toBe('right');
    expect(r.value).toBeCloseTo(90, 0);
    expect(angle({ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 0, y: 1 })).toBeCloseTo(90);
  });

  it('pinch: ratio near 0 when the tips touch, flags curled fingers', () => {
    const hand = (tipsTogether: boolean, curled: boolean): HandPoint[] =>
      HAND_NAMES.map((name, i) => {
        const pos: Record<number, [number, number]> = {
          0: [0, 0], 9: [0, -100], 4: tipsTogether ? [10, -150] : [-80, -120], 8: [10, -150],
          12: curled ? [0, -60] : [0, -190], 16: curled ? [20, -60] : [20, -185], 20: curled ? [40, -50] : [40, -170],
        };
        const p = pos[i] ?? [0, -50];
        return { name, x: p[0], y: p[1] };
      });
    const ex = new Exercise('pinch');
    expect(ex.readHand(hand(true, false), 'right').value).toBeCloseTo(0, 2);
    expect(ex.readHand(hand(false, false), 'right').compensations).toEqual([]);
    expect(ex.readHand(hand(true, true), 'right').compensations).toEqual(['fingersCurled']);
  });
});

describe('Session result (native SDK JSON shape)', () => {
  it('builds the same fields as rehab-engine', () => {
    const s = new Session('raise', 1, 'https://example/pose.task', 0);
    const values = [30, 30, 160, 165, 170, 40, 35, 30];
    values.forEach((v, i) => s.step({ ...new Exercise('raise').readPose([], null), value: v, side: 'right' }, true, i * 100));
    const r = s.result(1000);
    expect(Object.keys(r).sort()).toEqual([
      'attempts', 'best', 'compensations', 'completed', 'durationMs', 'exercise', 'model', 'repDetails', 'reps',
      'sdkVersion', 'series', 'startedAt', 'target', 'targetReps', 'trackingRatio', 'unit',
    ]);
    expect(r.reps).toBe(1);
    expect(r.completed).toBe(true);
    expect(r.repDetails[0].range).toBe(140);
    expect(r.compensations).toEqual({ trunkLean: 0, shoulderHike: 0, elbowBent: 0 });
    expect(r.series.intervalMs).toBe(200);
    expect(r.series.values).toEqual([30, 160, 170, 35]);
    expect(r.trackingRatio).toBe(1);
    expect(r.durationMs).toBe(1000);
  });
});
