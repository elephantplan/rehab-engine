// The five exercises with their compensation checks: a port of the native SDK's Exercise class
// (rehab-engine Exercises.kt), working on screen-pixel points (y down) like the native code.
// Pose points are named from the patient's side (pose/mediapipe.ts already swaps mirrored names).
import type { HandPoint } from '../hand/types';
import type { Keypoint, KeypointName } from '../pose/types';
import type { GaugeSpec } from '../ui/Goniometer';
import type { RepConfig } from './repCounter';
import type { RehabCompensation, RehabExercise, RehabSide } from './types';

export const EXERCISE_IDS: RehabExercise[] = ['raise', 'lateral', 'curl', 'wrist', 'pinch'];
/** A landmark counts as seen at or above this visibility. */
export const MIN_VISIBILITY = 0.5;

export const TRUNK_LEAN_DEGREES = 15;
export const STRAIGHT_ELBOW_DEGREES = 150;
export const UPPER_ARM_SWING_DEGREES = 35;
/** Fingertip-to-wrist distance over palm length: about 1.9 with the fingers straight. */
export const CURLED_FINGER_RATIO = 1.3;

type P = { x: number; y: number };

/** A point on the body: one keypoint, the middle of several, or "down the body" from the vertex. */
export type BodyRef = KeypointName | KeypointName[] | 'down';
/** An angle drawn on the camera view: the arc between vertex→a and vertex→c, labelled with value. */
export type Measure = { vertex: KeypointName; a: BodyRef; c: BodyRef; value: number | null };
type Side = 'left' | 'right';

/** What an exercise reads from one frame. */
export type Reading = {
  value: number | null;
  side: RehabSide;
  measures: Measure[];
  focus: KeypointName[];
  /** Extra coaching, such as uneven arms. */
  cue: string | null;
  compensations: RehabCompensation[];
  /** Shoulder-to-ear gap over shoulder width (smaller when the shoulder is hiked). */
  shrug: number | null;
  /** Direction of the forearm (elbow to wrist) in degrees. */
  forearm: number | null;
};

const empty = (side: RehabSide = null): Reading => ({
  value: null, side, measures: [], focus: [], cue: null, compensations: [], shrug: null, forearm: null,
});

/** Angle at vertex b formed by a-b-c, in degrees (0...180). */
export function angle(b: P, a: P, c: P): number {
  const ux = a.x - b.x, uy = a.y - b.y, vx = c.x - b.x, vy = c.y - b.y;
  const len = Math.hypot(ux, uy) * Math.hypot(vx, vy);
  if (len <= 0) return 0;
  return (Math.acos(Math.max(-1, Math.min(1, (ux * vx + uy * vy) / len))) * 180) / Math.PI;
}

const CONFIGS: Record<RehabExercise, RepConfig> = {
  raise: { activeAt: 150, restAt: 50, higherIsActive: true, partialMargin: 30, partialCue: '再舉高啲，舉過頭', missingCue: '請企後啲，令頭、膊頭同手臂入鏡' },
  lateral: { activeAt: 80, restAt: 30, higherIsActive: true, partialMargin: 20, partialCue: '再舉高啲，到膊頭高度', missingCue: '請企後啲，令兩隻手都入鏡' },
  curl: { activeAt: 60, restAt: 140, higherIsActive: false, partialMargin: 20, partialCue: '再屈多啲', missingCue: '請確保手臂（肩、手肘、手腕）入鏡' },
  wrist: { activeAt: 145, restAt: 165, higherIsActive: false, partialMargin: 8, partialCue: '手腕再屈多啲', missingCue: '要見到手肘：將成隻前臂放入鏡頭，側面對住鏡頭' },
  pinch: { activeAt: 0.18, restAt: 0.55, higherIsActive: false, partialMargin: 0.15, partialCue: '拇指同食指再靠近啲', missingCue: '將手掌對住鏡頭，成隻手入鏡' },
};

const LABELS: Record<RehabExercise, string> = {
  raise: '舉手過頭', lateral: '側平舉', curl: '屈手肘', wrist: '手腕屈伸', pinch: '拇指對食指',
};

const INSTRUCTIONS: Record<RehabExercise, string> = {
  raise: '面向鏡頭，上半身入鏡',
  lateral: '面向鏡頭，兩隻手向兩邊舉到膊頭高度',
  curl: '側面對鏡頭，上半身入鏡',
  wrist: '側面對鏡頭，要見到手肘同手掌',
  pinch: '手掌對住鏡頭，張開手再將拇指尖掂食指尖',
};

const CHECKS: Record<RehabExercise, RehabCompensation[]> = {
  raise: ['trunkLean', 'shoulderHike', 'elbowBent'],
  lateral: ['trunkLean', 'shoulderHike', 'elbowBent'],
  curl: ['upperArmSwing', 'trunkLean'],
  wrist: ['forearmMove'],
  pinch: ['fingersCurled'],
};

const GAUGES: Partial<Record<RehabExercise, GaugeSpec>> = {
  raise: { min: 0, max: 180, rest: [0, 50], target: [150, 180] },
  lateral: { min: 0, max: 180, rest: [0, 30], target: [80, 180] },
  curl: { min: 0, max: 180, rest: [140, 180], target: [0, 60] },
  wrist: { min: 90, max: 180, rest: [165, 180], target: [90, 145] },
};

export class Exercise {
  readonly id: RehabExercise;
  constructor(requested?: string | null) {
    this.id = (EXERCISE_IDS as string[]).includes(requested ?? '') ? (requested as RehabExercise) : 'raise';
  }
  get usesHand() { return this.id === 'pinch'; }
  get unit(): 'degrees' | 'ratio' { return this.usesHand ? 'ratio' : 'degrees'; }
  get config() { return CONFIGS[this.id]; }
  get label() { return LABELS[this.id]; }
  get instruction() { return INSTRUCTIONS[this.id]; }
  /** The checks this exercise runs (reported in the result even when zero). */
  get compensationChecks() { return CHECKS[this.id]; }
  get gauge() { return GAUGES[this.id]; }
  /** Landmarks that must be seen before anything is measured (raise and lateral face the camera). */
  get required(): KeypointName[] {
    return this.id === 'raise' || this.id === 'lateral' ? ['nose', 'leftShoulder', 'rightShoulder'] : [];
  }

  title(side: RehabSide) {
    const hand = side === 'left' ? '左手' : side === 'right' ? '右手' : '任何一隻手';
    return this.id === 'lateral' ? '側平舉・兩隻手一齊' : `${this.label}・${hand}`;
  }

  /** 0 with the hand open, 1 when the tips touch. */
  pinchProgress(ratio: number | null) {
    if (ratio == null) return 0;
    const c = this.config;
    return Math.max(0, Math.min(1, (c.restAt - ratio) / (c.restAt - c.activeAt)));
  }

  /** Pose exercises: screen points named from the patient's side; `tracked` is the side followed so far. */
  readPose(points: Keypoint[], tracked: RehabSide): Reading {
    const byName = new Map(points.map((k) => [k.name, k]));
    const seen = (n: KeypointName) => (byName.get(n)?.score ?? 0) >= MIN_VISIBILITY;
    const pt = (n: KeypointName): P => byName.get(n)!;
    if (!this.required.every(seen)) return empty();

    switch (this.id) {
      case 'lateral': {
        const left = elevation(pt, seen, 'leftShoulder', 'leftElbow');
        const right = elevation(pt, seen, 'rightShoulder', 'rightElbow');
        if (left == null || right == null) return empty('both');
        // The lower arm decides: both arms have to make it up.
        const value = Math.min(left, right);
        const cue = value > this.config.restAt && Math.abs(left - right) > 20 ? '兩隻手舉一樣高' : null;
        const flags = new Set<RehabCompensation>();
        const lean = trunkLean(pt, seen);
        if (lean != null && lean > TRUNK_LEAN_DEGREES) flags.add('trunkLean');
        for (const [side, lift] of [['left', left], ['right', right]] as const) {
          const [s, e, w] = arm(side);
          if (lift > 45 && seen(w) && angle(pt(e), pt(s), pt(w)) < STRAIGHT_ELBOW_DEGREES) flags.add('elbowBent');
        }
        // The more hiked shoulder decides.
        const gaps = [earGap(pt, seen, 'left'), earGap(pt, seen, 'right')].filter((g): g is number => g != null);
        return {
          ...empty('both'), value, cue, compensations: [...flags], shrug: gaps.length ? Math.min(...gaps) : null,
          focus: ['leftShoulder', 'leftElbow', 'rightShoulder', 'rightElbow'],
          measures: [
            { vertex: 'leftShoulder', a: 'down', c: 'leftElbow', value: left },
            { vertex: 'rightShoulder', a: 'down', c: 'rightElbow', value: right },
          ],
        };
      }
      case 'curl': {
        // Whichever arm is seen with all three joints; prefer the one already followed.
        const arms = (['right', 'left'] as Side[]).filter((sd) => arm(sd).every(seen));
        const side = arms.find((sd) => sd === tracked) ?? arms[0];
        if (!side) return empty();
        const [s, e, w] = arm(side);
        const value = angle(pt(e), pt(s), pt(w));
        const flags = new Set<RehabCompensation>();
        // Side-on, the upper arm should hang along the body: shoulder angle between hip and elbow.
        const hip = `${side}Hip` as KeypointName;
        if (seen(hip) && angle(pt(s), pt(hip), pt(e)) > UPPER_ARM_SWING_DEGREES) flags.add('upperArmSwing');
        const lean = trunkLean(pt, seen);
        if (lean != null && lean > TRUNK_LEAN_DEGREES) flags.add('trunkLean');
        return {
          ...empty(side), value, compensations: [...flags], focus: [e],
          measures: [{ vertex: e, a: s, c: w, value }],
        };
      }
      case 'wrist': {
        // Wrist bend: 180° with the hand in line with the forearm; the hand direction is the
        // middle of the index and pinky points. Coarse: pose landmarks are not finger tracking.
        const hands = (['right', 'left'] as Side[])
          .filter((sd) => ([`${sd}Elbow`, `${sd}Wrist`, `${sd}Index`, `${sd}Pinky`] as KeypointName[]).every(seen))
          .map((sd) => {
            const e = pt(`${sd}Elbow`), w = pt(`${sd}Wrist`), i = pt(`${sd}Index`), p = pt(`${sd}Pinky`);
            const mid = { x: (i.x + p.x) / 2, y: (i.y + p.y) / 2 };
            const value = angle(w, e, mid);
            const forearm = (Math.atan2(w.y - e.y, w.x - e.x) * 180) / Math.PI;
            return { side: sd, value, forearm };
          });
        // Stay on the hand already followed; otherwise the one bending more.
        const hand = hands.find((h) => h.side === tracked) ?? [...hands].sort((a, b) => a.value - b.value)[0];
        if (!hand) return empty();
        const sd = hand.side;
        return {
          ...empty(sd), value: hand.value, forearm: hand.forearm, focus: [`${sd}Wrist`],
          measures: [{ vertex: `${sd}Wrist`, a: `${sd}Elbow`, c: [`${sd}Index`, `${sd}Pinky`], value: hand.value }],
        };
      }
      case 'raise':
      default: {
        const left = elevation(pt, seen, 'leftShoulder', 'leftWrist');
        const right = elevation(pt, seen, 'rightShoulder', 'rightWrist');
        if (left == null && right == null) return empty();
        // The higher arm is followed; on a tie, the right.
        const side: Side = (right ?? -1) >= (left ?? -1) ? 'right' : 'left';
        const value = (side === 'right' ? right : left)!;
        const [s, e, w] = arm(side);
        const flags = new Set<RehabCompensation>();
        const lean = trunkLean(pt, seen);
        if (lean != null && lean > TRUNK_LEAN_DEGREES) flags.add('trunkLean');
        if (value > 60 && seen(e) && angle(pt(e), pt(s), pt(w)) < STRAIGHT_ELBOW_DEGREES) flags.add('elbowBent');
        // Near the top the shoulder blade rises naturally, so only judge shrugging below 120°.
        const shrug = value < 120 ? earGap(pt, seen, side) : null;
        return {
          ...empty(side), value, compensations: [...flags], shrug, focus: [s, w],
          measures: [{ vertex: s, a: 'down', c: w, value }],
        };
      }
    }
  }

  /** Pinch: one hand's 21 points in screen pixels (HAND_NAMES order) and its side. */
  readHand(hand: HandPoint[] | null, side: RehabSide): Reading {
    // Thumb tip to index tip over palm length (wrist to middle knuckle): about 1 with the
    // fingers spread, near 0 when they touch, whatever the distance from the camera.
    if (!hand || hand.length < 21) return empty();
    const d = (a: number, b: number) => Math.hypot(hand[a].x - hand[b].x, hand[a].y - hand[b].y);
    const palm = d(9, 0);
    if (palm <= 0) return empty();
    const ratio = d(4, 8) / palm;
    // Middle, ring and little fingertips should stay far from the wrist.
    const reach = [12, 16, 20].map((i) => d(i, 0) / palm);
    const curled = reach.reduce((t, r) => t + r, 0) / reach.length < CURLED_FINGER_RATIO;
    return { ...empty(side), value: ratio, compensations: curled ? ['fingersCurled'] : [] };
  }
}

const arm = (side: Side) =>
  [`${side}Shoulder`, `${side}Elbow`, `${side}Wrist`] as [KeypointName, KeypointName, KeypointName];

/**
 * Direction down the body: shoulders toward hips when the hips are clearly seen, else straight
 * down. Hidden hips (sitting at a desk) get guessed badly and would tilt the reference.
 */
function down(pt: (n: KeypointName) => P, seen: (n: KeypointName) => boolean): P {
  if ((['leftShoulder', 'rightShoulder', 'leftHip', 'rightHip'] as KeypointName[]).every(seen)) {
    const ls = pt('leftShoulder'), rs = pt('rightShoulder'), lh = pt('leftHip'), rh = pt('rightHip');
    const dx = (lh.x + rh.x - ls.x - rs.x) / 2, dy = (lh.y + rh.y - ls.y - rs.y) / 2;
    const len = Math.hypot(dx, dy);
    if (len > 0) return { x: dx / len, y: dy / len };
  }
  return { x: 0, y: 1 };
}

/** How far the trunk (hips to shoulders) leans from vertical, in degrees; null without both hips. */
function trunkLean(pt: (n: KeypointName) => P, seen: (n: KeypointName) => boolean): number | null {
  if (!(['leftShoulder', 'rightShoulder', 'leftHip', 'rightHip'] as KeypointName[]).every(seen)) return null;
  const ls = pt('leftShoulder'), rs = pt('rightShoulder'), lh = pt('leftHip'), rh = pt('rightHip');
  const dx = (ls.x + rs.x - lh.x - rh.x) / 2, dy = (ls.y + rs.y - lh.y - rh.y) / 2;
  if (dy >= 0) return null; // shoulders must be above the hips
  return (Math.atan2(Math.abs(dx), -dy) * 180) / Math.PI;
}

/** Shoulder-to-ear height over shoulder width: shrinks when the shoulder is pulled up. */
function earGap(pt: (n: KeypointName) => P, seen: (n: KeypointName) => boolean, side: Side): number | null {
  const s = `${side}Shoulder` as KeypointName, e = `${side}Ear` as KeypointName;
  if (!seen(s) || !seen(e) || !seen('leftShoulder') || !seen('rightShoulder')) return null;
  const l = pt('leftShoulder'), r = pt('rightShoulder');
  const width = Math.hypot(l.x - r.x, l.y - r.y);
  if (width <= 0) return null;
  return (pt(s).y - pt(e).y) / width;
}

/** How high an arm is raised: 0° hanging down, 90° level with the shoulder, 180° straight up. */
function elevation(pt: (n: KeypointName) => P, seen: (n: KeypointName) => boolean, s: KeypointName, t: KeypointName): number | null {
  if (!seen(s) || !seen(t)) return null;
  const d = down(pt, seen);
  const below = { x: pt(s).x + d.x * 60, y: pt(s).y + d.y * 60 };
  return angle(pt(s), below, pt(t));
}
