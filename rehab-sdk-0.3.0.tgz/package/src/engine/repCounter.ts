// Rep counting with per-rep detail, attempts and compensations. A line-for-line port of the
// native SDK's RepCounter (rehab-engine Exercises.kt / Exercises.swift) so both give the same
// numbers for the same movement.
import type { RehabCompensation, RehabSide } from './types';

export type RepConfig = {
  /** Value at which the movement counts as reached. */
  activeAt: number;
  /** Value at which the body counts as back at rest. */
  restAt: number;
  /** true when the active end is the larger value (raising an arm), false when smaller (bending). */
  higherIsActive: boolean;
  /** How far past rest an attempt must go before a partial rep gets coached. */
  partialMargin: number;
  partialCue: string;
  missingCue: string;
  doneCue?: string;
};

export const HOLD_FRAMES = 3;
export const MISSING_FRAMES = 4;
/** A compensation counts once it lasts this many frames in a movement. */
export const COMPENSATION_FRAMES = 3;
/** Shoulder hiking: the shoulder-to-ear gap falls below this share of its value at rest. */
export const SHRUG_DROP = 0.7;
/** Forearm moving: its direction turns more than this from where it pointed at rest. */
export const FOREARM_TURN_DEGREES = 20;

export const COMPENSATION_CUES: Record<RehabCompensation, string> = {
  trunkLean: '身體保持正直，唔好側彎',
  shoulderHike: '膊頭放鬆，唔好聳膊',
  elbowBent: '手肘伸直',
  upperArmSwing: '上臂貼住身邊，唔好郁膊頭',
  forearmMove: '前臂保持唔郁，只郁手腕',
  fingersCurled: '其他手指保持伸直',
};

export type RepDetail = {
  peak: number; start: number; durationMs: number; holdMs: number; atMs: number;
  side: RehabSide; compensations: RehabCompensation[];
};
export type Attempt = { peak: number; start: number; atMs: number; side: RehabSide; compensations: RehabCompensation[] };

export class RepCounter {
  reps = 0;
  value: number | null = null;
  cue: string | null = null;
  /** Furthest value toward the active end in the whole session. */
  best: number | null = null;
  readonly repDetails: RepDetail[] = [];
  readonly attempts: Attempt[] = [];

  private active = false;
  private peak: number | null = null;
  private pending = 0;
  private missing = 0;
  private lastSide: RehabSide = null;
  private lastRest: number | null = null;
  private moveStartedAt: number | null = null;
  private moveStart: number | null = null;
  private firstReachedAt: number | null = null;
  private lastReachedAt: number | null = null;
  private moveCompensations = new Set<RehabCompensation>();
  private compensationRun = new Map<RehabCompensation, number>();
  private shrugBaseline: number | null = null;
  private forearmBaseline: number | null = null;

  /** `originMs` is the session start on the same clock as step()'s time. */
  constructor(private readonly config: RepConfig, private readonly originMs: number) {}

  private resetMove() {
    this.peak = null;
    this.moveStartedAt = null;
    this.moveStart = null;
    this.firstReachedAt = null;
    this.lastReachedAt = null;
    this.moveCompensations = new Set();
    this.compensationRun = new Map();
  }

  private sortedCompensations() {
    return [...this.moveCompensations].sort();
  }

  step(
    reading: number | null, side: RehabSide, timeMs: number,
    compensations: RehabCompensation[] = [], shrug: number | null = null, forearm: number | null = null,
  ) {
    this.cue = null;
    const c = this.config;
    if (reading == null) {
      this.value = null;
      this.missing += 1;
      if (this.missing >= MISSING_FRAMES) {
        this.active = false;
        this.pending = 0;
        this.resetMove();
        this.cue = c.missingCue;
      }
      return;
    }
    this.missing = 0;
    this.value = reading;
    if (side != null) this.lastSide = side;

    const further = (a: number, b: number) => (c.higherIsActive ? a > b : a < b);
    this.best = this.best == null || further(reading, this.best) ? reading : this.best;
    const atRest = c.higherIsActive ? reading <= c.restAt : reading >= c.restAt;
    const reached = c.higherIsActive ? reading >= c.activeAt : reading <= c.activeAt;
    const idle = !this.active && this.moveStartedAt == null;

    if (atRest) {
      if (idle) this.lastRest = reading;
    } else {
      this.peak = this.peak == null || further(reading, this.peak) ? reading : this.peak;
      if (this.moveStartedAt == null) {
        this.moveStartedAt = timeMs;
        this.moveStart = this.lastRest ?? reading;
      }
    }
    if (reached) {
      if (this.firstReachedAt == null) this.firstReachedAt = timeMs;
      this.lastReachedAt = timeMs;
    }

    // Compensations count only during a movement, once they last a few frames.
    const flags = new Set(compensations);
    if (shrug != null) {
      const base = this.shrugBaseline;
      if (atRest && idle) {
        this.shrugBaseline = base != null ? base * 0.8 + shrug * 0.2 : shrug;
      } else if (base != null && base > 0 && shrug < base * SHRUG_DROP) {
        flags.add('shoulderHike');
      }
    }
    if (forearm != null) {
      const base = this.forearmBaseline;
      if (atRest && idle) {
        this.forearmBaseline = forearm;
      } else if (base != null) {
        let turn = Math.abs(forearm - base) % 360;
        if (turn > 180) turn = 360 - turn;
        if (turn > FOREARM_TURN_DEGREES) flags.add('forearmMove');
      }
    }
    let newCompensation: RehabCompensation | null = null;
    if (this.moveStartedAt != null) {
      for (const k of [...this.compensationRun.keys()]) if (!flags.has(k)) this.compensationRun.set(k, 0);
      for (const flag of flags) {
        const run = (this.compensationRun.get(flag) ?? 0) + 1;
        this.compensationRun.set(flag, run);
        if (run >= COMPENSATION_FRAMES && !this.moveCompensations.has(flag)) {
          this.moveCompensations.add(flag);
          newCompensation = flag;
        }
      }
    }

    if (!this.active) {
      this.pending = reached ? this.pending + 1 : 0;
      if (this.pending >= HOLD_FRAMES) {
        this.active = true;
        this.pending = 0;
      } else if (atRest) {
        // Came back to rest without reaching the target.
        const p = this.peak;
        if (p != null && Math.abs(p - c.restAt) >= c.partialMargin) {
          this.cue = c.partialCue;
          this.attempts.push({
            peak: p, start: this.moveStart ?? reading, atMs: (this.moveStartedAt ?? timeMs) - this.originMs,
            side: this.lastSide, compensations: this.sortedCompensations(),
          });
        }
        this.resetMove();
      }
    } else {
      this.pending = atRest ? this.pending + 1 : 0;
      if (this.pending >= HOLD_FRAMES) {
        this.active = false;
        this.pending = 0;
        const began = this.moveStartedAt ?? timeMs;
        const hold = this.firstReachedAt != null && this.lastReachedAt != null ? this.lastReachedAt - this.firstReachedAt : 0;
        this.repDetails.push({
          peak: this.peak ?? reading, start: this.moveStart ?? reading, durationMs: timeMs - began, holdMs: hold,
          atMs: began - this.originMs, side: this.lastSide, compensations: this.sortedCompensations(),
        });
        this.resetMove();
        this.lastRest = reading;
        this.reps += 1;
        this.cue = c.doneCue ?? '做得好！';
      }
    }
    if (this.cue == null && newCompensation) this.cue = COMPENSATION_CUES[newCompensation];
  }
}
