// The result format, identical to the native SDK (rehab-engine index.d.ts), so a mini app can
// switch between the two SDKs without changing how it stores or charts results.

/**
 * - raise   舉手過頭: either arm up over the head (face the camera)
 * - lateral 側平舉: both arms out to shoulder height together (face the camera)
 * - curl    屈手肘: bend the elbow (side-on)
 * - wrist   手腕屈伸: bend the wrist up or down (side-on, forearm in view)
 * - pinch   拇指對食指: touch thumb tip to index tip (palm to the camera; hand tracking)
 */
export type RehabExercise = 'raise' | 'lateral' | 'curl' | 'wrist' | 'pinch';

export type RehabSide = 'left' | 'right' | 'both' | null;

/**
 * Movements that make an exercise look done without the joint doing the work. Each counts once
 * it lasts 3 frames within a movement; the patient sees a cue the first time.
 * - trunkLean     trunk leans more than 15° from vertical (needs both hips in view) — raise, lateral, curl
 * - shoulderHike  shoulder-to-ear gap drops below 70% of its value at rest — raise (below 120°), lateral
 * - elbowBent     elbow under 150° while the arm should stay straight — raise, lateral
 * - upperArmSwing upper arm more than 35° away from the body — curl
 * - forearmMove   forearm turns more than 20° from its direction at rest — wrist
 * - fingersCurled middle, ring and little fingertips pulled in towards the wrist — pinch
 */
export type RehabCompensation =
  | 'trunkLean'
  | 'shoulderHike'
  | 'elbowBent'
  | 'upperArmSwing'
  | 'forearmMove'
  | 'fingersCurled';

/** All values are in the result's unit (degrees, or the pinch ratio). */
export type RehabEngineRep = {
  /** Furthest value reached in this rep. */
  peak: number;
  /** Value at rest just before the movement began. */
  start: number;
  /** Range of motion: |peak − start|. */
  range: number;
  /** From leaving the rest position to coming back. */
  durationMs: number;
  /** Time spent in the target zone (beyond target.activeAt). */
  holdMs: number;
  /** When the movement began, from the start of the session. */
  atMs: number;
  side: RehabSide;
  compensations: RehabCompensation[];
};

/** A movement that left rest but came back without reaching the target. */
export type RehabEngineAttempt = {
  peak: number;
  start: number;
  atMs: number;
  side: RehabSide;
  compensations: RehabCompensation[];
};

export type RehabEngineResult = {
  exercise: RehabExercise;
  /** 'degrees' for angle exercises; 'ratio' for pinch (thumb–index gap over palm length). */
  unit: 'degrees' | 'ratio';
  /** Reps that reached the target. Success rate: reps / (reps + attempts.length). */
  reps: number;
  durationMs: number;
  /** Session start, milliseconds since 1970. */
  startedAt: number;
  /** Furthest value toward the target in the whole session, or null when never tracked. */
  best: number | null;
  /** The zones this session was judged against. */
  target: { activeAt: number; restAt: number };
  repDetails: RehabEngineRep[];
  attempts: RehabEngineAttempt[];
  /** For each check this exercise runs, how many reps and attempts showed it (0 included). */
  compensations: Partial<Record<RehabCompensation, number>>;
  /** The measured value every intervalMs (null while not tracked). At most 10 minutes. */
  series: { intervalMs: number; values: (number | null)[] };
  /** Share of analysed frames (0...1) where the patient was clearly in view. */
  trackingRatio: number;
  targetReps: number | null;
  completed: boolean | null;
  /** SDK version that produced this result. */
  sdkVersion: string;
  /** Where the model came from: "bundled" or its download URL. */
  model: string;
};
