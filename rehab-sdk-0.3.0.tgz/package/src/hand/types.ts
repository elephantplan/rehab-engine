// MediaPipe Hand Landmarker's 21 points, in its order.
export const HAND_NAMES = [
  'wrist',
  'thumbCmc', 'thumbMcp', 'thumbIp', 'thumbTip',
  'indexMcp', 'indexPip', 'indexDip', 'indexTip',
  'middleMcp', 'middlePip', 'middleDip', 'middleTip',
  'ringMcp', 'ringPip', 'ringDip', 'ringTip',
  'pinkyMcp', 'pinkyPip', 'pinkyDip', 'pinkyTip',
] as const;

export type HandName = (typeof HAND_NAMES)[number];

/** A hand point in screen pixels. */
export type HandPoint = { name: HandName; x: number; y: number };

export const HAND_BONES: [HandName, HandName][] = [
  ['wrist', 'thumbCmc'], ['thumbCmc', 'thumbMcp'], ['thumbMcp', 'thumbIp'], ['thumbIp', 'thumbTip'],
  ['wrist', 'indexMcp'], ['indexMcp', 'indexPip'], ['indexPip', 'indexDip'], ['indexDip', 'indexTip'],
  ['middleMcp', 'middlePip'], ['middlePip', 'middleDip'], ['middleDip', 'middleTip'],
  ['ringMcp', 'ringPip'], ['ringPip', 'ringDip'], ['ringDip', 'ringTip'],
  ['wrist', 'pinkyMcp'], ['pinkyMcp', 'pinkyPip'], ['pinkyPip', 'pinkyDip'], ['pinkyDip', 'pinkyTip'],
  ['indexMcp', 'middleMcp'], ['middleMcp', 'ringMcp'], ['ringMcp', 'pinkyMcp'],
];
