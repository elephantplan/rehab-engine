import { useMemo } from 'react';
import { Platform } from 'react-native';
import { VisionCameraProxy, runAtTargetFps, useFrameProcessor, type Orientation } from 'react-native-vision-camera';
import { Worklets } from 'react-native-worklets-core';

export type HandResult = {
  width: number;
  height: number;
  /** Per hand, 21 [x, y, z] points normalised to the image. */
  hands: number[][][];
  handedness: string[];
  error?: string;
};

// Hand tracking is heavier than pose; 15 fps keeps older iPhones responsive.
const HAND_FPS = 15;

// One plugin instance per model file; the plugin loads the model when it is created.
const plugins = new Map<string, ReturnType<typeof VisionCameraProxy.initFrameProcessorPlugin>>();
function pluginFor(modelPath: string) {
  // The native plugin only exists on iOS for now; elsewhere this stays undefined.
  if (Platform.OS !== 'ios') return undefined;
  if (!plugins.has(modelPath)) {
    plugins.set(modelPath, VisionCameraProxy.initFrameProcessorPlugin('handLandmarks', { model: modelPath, numHands: 1 }));
  }
  return plugins.get(modelPath);
}

/**
 * A frame processor that runs MediaPipe Hand Landmarker and hands results to `onResult` on the JS thread.
 * `modelPath` is the downloaded hand model (absolute file path).
 */
export function useHandLandmarks(onResult: (r: HandResult, frameOrientation: Orientation) => void, modelPath: string) {
  const plugin = useMemo(() => pluginFor(modelPath), [modelPath]);
  const onResultJS = useMemo(() => Worklets.createRunOnJS(onResult), [onResult]);
  const frameProcessor = useFrameProcessor(
    (frame) => {
      'worklet';
      if (plugin == null) return;
      runAtTargetFps(HAND_FPS, () => {
        'worklet';
        const r = plugin.call(frame, { orientation: 'portrait' });
        if (r != null) onResultJS(r as unknown as HandResult, frame.orientation);
      });
    },
    [onResultJS, plugin],
  );
  return { frameProcessor, available: plugin != null };
}
