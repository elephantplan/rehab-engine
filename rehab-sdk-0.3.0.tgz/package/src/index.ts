// Public API of the rehab SDK. Host apps import only from here.
export { RehabSession } from './RehabSession';
export type { RehabSessionProps } from './RehabSession';
// Result types: identical to the native SDK (rehab-engine), so mini app code works with either.
export type {
  RehabExercise, RehabSide, RehabCompensation, RehabEngineRep, RehabEngineAttempt, RehabEngineResult,
} from './engine/types';
export { EXERCISE_IDS } from './engine/exercises';
export { SDK_VERSION } from './engine/session';

// Model files are downloaded at run time. Call preloadModels() when the mini app opens.
export { preloadModels, DEFAULT_MODEL_URLS } from './models/modelStore';
export type { ModelUrls, ModelPaths } from './models/modelStore';
