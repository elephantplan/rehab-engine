// Downloads the MediaPipe model files at run time and keeps them on the phone, so the host app's
// install does not carry them. Call preloadModels() when the mini app opens; RehabSession waits
// for the files (and downloads them itself if preload was skipped).
import * as FileSystem from 'expo-file-system';

export type ModelName = 'pose' | 'hand';
export type ModelUrls = Partial<Record<ModelName, string>>;
/** Absolute file paths (no file:// prefix), as the native MediaPipe code expects. */
export type ModelPaths = Record<ModelName, string>;

/** Google's public files. Production apps should host copies on their own server and pass modelUrls. */
export const DEFAULT_MODEL_URLS: Record<ModelName, string> = {
  pose: 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/latest/pose_landmarker_full.task',
  hand: 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task',
};

const FILE_NAMES: Record<ModelName, string> = { pose: 'pose_landmarker.task', hand: 'hand_landmarker.task' };

function dir(): string {
  if (!FileSystem.documentDirectory) throw new Error('No document directory on this device');
  return `${FileSystem.documentDirectory}rehab-models/`;
}

const toPath = (uri: string) => decodeURI(uri.replace(/^file:\/\//, ''));

// One download per model at a time, shared by preload and RehabSession.
const inFlight = new Map<string, Promise<string>>();

async function ensureModel(name: ModelName, url: string, onProgress?: (fraction: number) => void): Promise<string> {
  const key = `${name}|${url}`;
  const running = inFlight.get(key);
  if (running) return running;
  const job = (async () => {
    const folder = dir();
    const file = folder + FILE_NAMES[name];
    const meta = `${file}.url`;
    const [info, metaInfo] = await Promise.all([FileSystem.getInfoAsync(file), FileSystem.getInfoAsync(meta)]);
    // Reuse the file only if it was downloaded from the same URL; a new URL means a new model.
    if (info.exists && metaInfo.exists && (await FileSystem.readAsStringAsync(meta)) === url) return toPath(file);

    await FileSystem.makeDirectoryAsync(folder, { intermediates: true });
    const tmp = `${file}.download`;
    await FileSystem.deleteAsync(tmp, { idempotent: true });
    const task = FileSystem.createDownloadResumable(url, tmp, {}, (p) => {
      if (p.totalBytesExpectedToWrite > 0) onProgress?.(p.totalBytesWritten / p.totalBytesExpectedToWrite);
    });
    const res = await task.downloadAsync();
    if (!res || res.status < 200 || res.status >= 300) {
      await FileSystem.deleteAsync(tmp, { idempotent: true });
      throw new Error(`Model download failed (${res?.status ?? 'no response'}): ${url}`);
    }
    // Move into place only after a complete download, so a cut-off download is never used.
    await FileSystem.deleteAsync(file, { idempotent: true });
    await FileSystem.moveAsync({ from: tmp, to: file });
    await FileSystem.writeAsStringAsync(meta, url);
    return toPath(file);
  })();
  inFlight.set(key, job);
  try {
    return await job;
  } finally {
    inFlight.delete(key);
  }
}

/**
 * Makes sure the model files are on the phone. Downloads only what is missing or whose URL changed.
 * Call it when the mini app opens so the exercise screen starts without waiting.
 */
export async function preloadModels(urls: ModelUrls = {}, onProgress?: (fraction: number) => void): Promise<ModelPaths> {
  const all = { ...DEFAULT_MODEL_URLS, ...urls };
  const done: Record<ModelName, number> = { pose: 0, hand: 0 };
  const report = (name: ModelName) => (f: number) => {
    done[name] = f;
    onProgress?.((done.pose + done.hand) / 2);
  };
  const [pose, hand] = await Promise.all([
    ensureModel('pose', all.pose, report('pose')),
    ensureModel('hand', all.hand, report('hand')),
  ]);
  onProgress?.(1);
  return { pose, hand };
}
