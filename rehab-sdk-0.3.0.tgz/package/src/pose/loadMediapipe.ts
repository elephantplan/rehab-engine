// Loads the MediaPipe library lazily. If its native side is missing or its frame processor
// plugin did not register, the import throws; catching it lets the app show why instead of closing.
type Mediapipe = typeof import('react-native-mediapipe-posedetection');

export let mediapipe: Mediapipe | null = null;
export let mediapipeLoadError: string | null = null;

try {
  mediapipe = require('react-native-mediapipe-posedetection') as Mediapipe;
} catch (e) {
  mediapipeLoadError = e instanceof Error ? e.message : String(e);
}
