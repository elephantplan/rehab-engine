import type { Landmark } from 'react-native-mediapipe-posedetection';
import { Platform } from 'react-native';
import { KEYPOINT_NAMES, Keypoint, KeypointName } from './types';

const confidence = (l: Landmark) => l.visibility ?? l.presence ?? 1;

/**
 * iOS front-camera frames reach MediaPipe mirrored, so its "left" is the person's right.
 * Swapping the names makes 左手 / 右手 mean the person's own hands.
 */
const SWAP_SIDES = Platform.OS === 'ios';
const NAME_AT = KEYPOINT_NAMES.map((name) =>
  SWAP_SIDES ? ((name.startsWith('left') ? name.replace('left', 'right') : name.replace('right', 'left')) as KeypointName) : name,
);

/** MediaPipe world landmarks (metres, 3D) → keypoints for angle analysis. */
export function worldToKeypoints(world: Landmark[], image: Landmark[]): Keypoint[] {
  return KEYPOINT_NAMES.map((_, i) => {
    const name = NAME_AT[i];
    const w = world[i];
    // Visibility comes from the image landmarks; world landmarks may leave it out.
    const score = image[i] ? confidence(image[i]) : w ? confidence(w) : 0;
    return { name, x: w?.x ?? 0, y: w?.y ?? 0, z: w?.z ?? 0, score };
  });
}

/** MediaPipe image landmarks → keypoints in screen pixels, via the library's view converter. */
export function imageToScreen(image: Landmark[], toView: (p: { x: number; y: number }) => { x: number; y: number }): Keypoint[] {
  return KEYPOINT_NAMES.map((_, i) => {
    const name = NAME_AT[i];
    const l = image[i];
    if (!l) return { name, x: 0, y: 0, score: 0 };
    const p = toView({ x: l.x, y: l.y });
    return { name, x: p.x, y: p.y, score: confidence(l) };
  });
}
