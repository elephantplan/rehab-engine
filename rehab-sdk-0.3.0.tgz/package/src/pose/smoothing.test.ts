import { KeypointSmoother, OneEuroFilter } from './smoothing';
import { Keypoint } from './types';

const spread = (xs: number[]) => Math.max(...xs) - Math.min(...xs);

describe('OneEuroFilter', () => {
  it('reduces jitter on a still point', () => {
    const f = new OneEuroFilter();
    const raw: number[] = [];
    const out: number[] = [];
    for (let i = 0; i < 60; i++) {
      const v = 0.5 + (i % 2 ? 0.01 : -0.01);
      raw.push(v);
      out.push(f.filter(v, i / 15));
    }
    expect(spread(out.slice(20))).toBeLessThan(spread(raw) / 3);
  });

  it('follows a sustained move', () => {
    const f = new OneEuroFilter();
    let last = 0;
    for (let i = 0; i < 30; i++) last = f.filter(i < 5 ? 0.2 : 0.8, i / 15);
    expect(last).toBeGreaterThan(0.78);
  });
});

describe('KeypointSmoother', () => {
  it('passes low-confidence points through untouched', () => {
    const s = new KeypointSmoother();
    const kp: Keypoint = { name: 'nose', x: 0.3, y: 0.4, score: 0.1 };
    s.smooth([{ ...kp, x: 0.9, score: 0.9 }], 0);
    expect(s.smooth([kp], 66)[0]).toEqual(kp);
  });
});
