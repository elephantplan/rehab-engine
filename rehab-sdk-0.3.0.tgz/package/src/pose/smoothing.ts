import { Keypoint } from './types';
import { MIN_SCORE } from '../analysis/angles';

// One Euro Filter (Casiez et al. 2012): smooths heavily when a point is still,
// lightly when it moves fast, so jitter drops without adding much lag.
export type OneEuroParams = {
  /** Smoothing at rest. Lower = steadier but laggier. */
  minCutoff: number;
  /** How quickly smoothing relaxes as speed rises. Higher = less lag on fast moves. */
  beta: number;
  /** Cutoff for the speed estimate itself. */
  dCutoff: number;
};

export const DEFAULT_ONE_EURO: OneEuroParams = { minCutoff: 0.6, beta: 5.0, dCutoff: 1.0 };

const alpha = (cutoff: number, dt: number) => {
  const tau = 1 / (2 * Math.PI * cutoff);
  return 1 / (1 + tau / dt);
};

export class OneEuroFilter {
  private x: number | null = null;
  private dx = 0;
  private t = 0;

  constructor(private readonly p: OneEuroParams = DEFAULT_ONE_EURO) {}

  /** `t` in seconds. */
  filter(value: number, t: number): number {
    if (this.x == null || t <= this.t) {
      this.x = value;
      this.t = t;
      return value;
    }
    const dt = t - this.t;
    const rawDx = (value - this.x) / dt;
    this.dx += alpha(this.p.dCutoff, dt) * (rawDx - this.dx);
    const cutoff = this.p.minCutoff + this.p.beta * Math.abs(this.dx);
    this.x += alpha(cutoff, dt) * (value - this.x);
    this.t = t;
    return this.x;
  }

  reset() {
    this.x = null;
    this.dx = 0;
  }
}

/** Smooths every keypoint's x/y (and z when present). Low-confidence points pass through and reset their filter. */
export class KeypointSmoother {
  private filters = new Map<string, [OneEuroFilter, OneEuroFilter, OneEuroFilter]>();

  constructor(private readonly p: OneEuroParams = DEFAULT_ONE_EURO) {}

  smooth(keypoints: Keypoint[], timestampMs: number): Keypoint[] {
    const t = timestampMs / 1000;
    return keypoints.map((kp) => {
      let pair = this.filters.get(kp.name);
      if (!pair) {
        pair = [new OneEuroFilter(this.p), new OneEuroFilter(this.p), new OneEuroFilter(this.p)];
        this.filters.set(kp.name, pair);
      }
      if (kp.score < MIN_SCORE) {
        pair.forEach((f) => f.reset());
        return kp;
      }
      const z = kp.z == null ? undefined : pair[2].filter(kp.z, t);
      return { ...kp, x: pair[0].filter(kp.x, t), y: pair[1].filter(kp.y, t), z };
    });
  }
}
