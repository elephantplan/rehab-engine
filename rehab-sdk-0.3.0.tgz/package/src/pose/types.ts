// App-wide pose format. Every provider (MediaPipe now, a partner SDK later) maps into this.
// The order matches MediaPipe Pose Landmarker's 33 landmarks.
export const KEYPOINT_NAMES = [
  'nose', 'leftEyeInner', 'leftEye', 'leftEyeOuter', 'rightEyeInner', 'rightEye', 'rightEyeOuter',
  'leftEar', 'rightEar', 'mouthLeft', 'mouthRight',
  'leftShoulder', 'rightShoulder', 'leftElbow', 'rightElbow', 'leftWrist', 'rightWrist',
  'leftPinky', 'rightPinky', 'leftIndex', 'rightIndex', 'leftThumb', 'rightThumb',
  'leftHip', 'rightHip', 'leftKnee', 'rightKnee', 'leftAnkle', 'rightAnkle',
  'leftHeel', 'rightHeel', 'leftFootIndex', 'rightFootIndex',
] as const;

export type KeypointName = (typeof KEYPOINT_NAMES)[number];

/**
 * For analysis: x, y, z in metres around the hips (MediaPipe world landmarks), so angles are
 * true 3D angles. For drawing: x, y in screen pixels and no z.
 */
export type Keypoint = { name: KeypointName; x: number; y: number; z?: number; score: number };
