import React, { useEffect, useRef } from 'react';
import { AccessibilityInfo, Animated, StyleSheet, Text } from 'react-native';
import { colors, type } from './theme';

export type CueKind = 'success' | 'correct' | 'position';

/** Sorts a coaching message so its colour says what kind of message it is. */
export function cueKind(cue: string): CueKind {
  if (cue.includes('做得好')) return 'success';
  if (cue.includes('入鏡') || cue.includes('鏡頭')) return 'position';
  return 'correct';
}

const LOOK: Record<CueKind, { bg: string; fg: string }> = {
  success: { bg: colors.sage, fg: colors.card },
  correct: { bg: colors.amberSoft, fg: colors.ink },
  position: { bg: 'rgba(20,32,43,0.78)', fg: colors.bone },
};

/** The coaching message, floating over the camera. Slides in when the text changes. */
export function CueBanner({ cue }: { cue: string | null }) {
  const anim = useRef(new Animated.Value(cue ? 1 : 0)).current;
  useEffect(() => {
    let cancelled = false;
    AccessibilityInfo.isReduceMotionEnabled().then((reduce) => {
      if (cancelled) return;
      anim.setValue(cue && !reduce ? 0 : cue ? 1 : 0);
      if (cue && !reduce) Animated.spring(anim, { toValue: 1, useNativeDriver: true, friction: 7 }).start();
    });
    return () => {
      cancelled = true;
    };
  }, [cue, anim]);
  if (!cue) return null;
  const look = LOOK[cueKind(cue)];
  return (
    <Animated.View
      accessibilityLiveRegion="polite"
      style={[
        styles.banner,
        { backgroundColor: look.bg, opacity: anim, transform: [{ translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [12, 0] }) }] },
      ]}
    >
      <Text style={[type.body, styles.text, { color: look.fg }]}>{cue}</Text>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  // A compact pill centred above the panel, so it does not cover the body.
  banner: {
    position: 'absolute', bottom: 40, alignSelf: 'center', maxWidth: '86%',
    paddingVertical: 8, paddingHorizontal: 16, borderRadius: 999,
  },
  text: { fontWeight: '700', textAlign: 'center' },
});
