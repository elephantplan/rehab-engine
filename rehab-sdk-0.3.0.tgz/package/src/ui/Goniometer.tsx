import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Line, Path } from 'react-native-svg';
import { colors, type } from './theme';

export type GaugeSpec = { min: number; max: number; rest: [number, number]; target: [number, number] };

type Props = { gauge: GaugeSpec; value: number | null; size?: number };

/** A physiotherapist's goniometer: rest band, target band and a needle at the live angle. */
export function Goniometer({ gauge, value, size = 168 }: Props) {
  const stroke = 12;
  const r = size / 2 - stroke;
  const cx = size / 2;
  const cy = size / 2 + 4;
  const clamp = (v: number) => Math.min(gauge.max, Math.max(gauge.min, v));
  const polar = (v: number, radius = r) => {
    const t = (clamp(v) - gauge.min) / (gauge.max - gauge.min);
    const phi = Math.PI * (1 - t);
    return { x: cx + radius * Math.cos(phi), y: cy - radius * Math.sin(phi) };
  };
  const arc = (a: number, b: number) => {
    const p = polar(Math.min(a, b));
    const q = polar(Math.max(a, b));
    return `M ${p.x} ${p.y} A ${r} ${r} 0 0 1 ${q.x} ${q.y}`;
  };
  const inTarget = value != null && value >= gauge.target[0] && value <= gauge.target[1];
  const needleColor = inTarget ? colors.sage : colors.cobalt;
  const ticks = Array.from({ length: 13 }, (_, i) => gauge.min + ((gauge.max - gauge.min) * i) / 12);
  const tip = value == null ? null : polar(value, r - stroke);

  return (
    <View style={{ width: size, alignItems: 'center' }}>
      <Svg width={size} height={size / 2 + 16}>
        <Path d={arc(gauge.min, gauge.max)} stroke={colors.hairline} strokeWidth={stroke} fill="none" strokeLinecap="round" />
        <Path d={arc(gauge.rest[0], gauge.rest[1])} stroke={colors.slateSoft} strokeWidth={stroke} fill="none" />
        <Path d={arc(gauge.target[0], gauge.target[1])} stroke={inTarget ? colors.sage : colors.sageSoft} strokeWidth={stroke} fill="none" />
        {ticks.map((t, i) => {
          const a = polar(t, r - stroke / 2 - 4);
          const b = polar(t, r - stroke / 2 - (i % 3 === 0 ? 14 : 9));
          return <Line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={colors.slate} strokeWidth={i % 3 === 0 ? 2 : 1} />;
        })}
        {tip && <Line x1={cx} y1={cy} x2={tip.x} y2={tip.y} stroke={needleColor} strokeWidth={4} strokeLinecap="round" />}
        <Circle cx={cx} cy={cy} r={7} fill={tip ? needleColor : colors.slateSoft} />
      </Svg>
      <Text style={[type.angle, styles.readout, { color: value == null ? colors.slate : colors.ink }]}>
        {value == null ? '–' : `${Math.round(value)}°`}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  readout: { marginTop: -6 },
});
