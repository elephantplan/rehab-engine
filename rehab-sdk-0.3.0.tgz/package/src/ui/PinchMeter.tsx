import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, type } from './theme';

/** How close the thumb and index tips are: empty with the hand open, full when they touch. */
export function PinchMeter({ progress, label }: { progress: number; label: string }) {
  const done = progress >= 1;
  return (
    <View style={styles.wrap} accessible accessibilityLabel={`${label} ${Math.round(progress * 100)}%`}>
      <Text style={[type.label, styles.label]}>{label}</Text>
      <View style={styles.track}>
        <View style={[styles.fill, { width: `${Math.round(progress * 100)}%`, backgroundColor: done ? colors.sage : colors.cobalt }]} />
      </View>
      <Text style={[type.angle, { color: colors.ink }]}>{`${Math.round(progress * 100)}%`}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { width: 168, gap: 8, alignItems: 'flex-end' },
  label: { color: colors.slate },
  track: { width: '100%', height: 14, borderRadius: 7, backgroundColor: colors.hairline, overflow: 'hidden' },
  fill: { height: '100%', borderRadius: 7 },
});
