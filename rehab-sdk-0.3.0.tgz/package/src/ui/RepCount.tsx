import React, { useEffect, useRef } from 'react';
import { AccessibilityInfo, Animated, StyleSheet, Text, View } from 'react-native';
import { colors, type } from './theme';

/** The rep total, as "3 / 10" when there is a target. Gives a small bump each time it goes up. */
export function RepCount({ reps, target }: { reps: number; target?: number | null }) {
  const scale = useRef(new Animated.Value(1)).current;
  const last = useRef(reps);
  useEffect(() => {
    if (reps <= last.current) {
      last.current = reps;
      return;
    }
    last.current = reps;
    AccessibilityInfo.isReduceMotionEnabled().then((reduce) => {
      if (reduce) return;
      scale.setValue(1.18);
      Animated.spring(scale, { toValue: 1, useNativeDriver: true, friction: 4 }).start();
    });
  }, [reps, scale]);
  return (
    <View accessible accessibilityLabel={target ? `完成 ${reps} 次，目標 ${target} 次` : `完成 ${reps} 次`}>
      <Text style={[type.label, styles.label]}>完成次數</Text>
      <View style={styles.row}>
        <Animated.Text style={[type.repCount, styles.count, { transform: [{ scale }] }]}>{reps}</Animated.Text>
        <Text style={[type.title, styles.unit]}>{target ? `/ ${target} 次` : '次'}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  label: { color: colors.slate },
  row: { flexDirection: 'row', alignItems: 'baseline', gap: 6 },
  count: { color: colors.ink, lineHeight: 96 },
  unit: { color: colors.slate },
});
