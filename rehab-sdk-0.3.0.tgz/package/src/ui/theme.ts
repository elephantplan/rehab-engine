// Clinic-at-home palette: porcelain panel for easy reading, cobalt for the measured joint and
// needle, sage when the movement is in the target range, amber for corrections.
export const colors = {
  ink: '#14202B',
  stage: '#0B1016',
  porcelain: '#F3F6F8',
  card: '#FFFFFF',
  hairline: '#DDE3E8',
  slate: '#6B7A88',
  slateSoft: '#C9D2DA',
  cobalt: '#2F5BEA',
  cobaltSoft: '#DCE5FD',
  sage: '#2E9E6B',
  sageSoft: '#D5EFE2',
  amber: '#C9800E',
  amberSoft: '#FBEBCF',
  bone: '#F8FAFC',
};

export const type = {
  // Big readouts use tabular figures so digits do not shift as they change.
  repCount: { fontSize: 88, fontWeight: '800' as const, letterSpacing: -3, fontVariant: ['tabular-nums' as const] },
  angle: { fontSize: 30, fontWeight: '700' as const, fontVariant: ['tabular-nums' as const] },
  title: { fontSize: 22, fontWeight: '700' as const },
  body: { fontSize: 16, fontWeight: '500' as const },
  label: { fontSize: 13, fontWeight: '600' as const, letterSpacing: 0.6 },
};
