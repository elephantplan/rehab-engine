# rehab-sdk

A React Native SDK for home rehab exercises. It contains the **whole exercise screen**: front camera,
stick-figure skeleton or hand overlay, joint angles drawn on the body, a goniometer dial, rep counting
and coaching messages. Detection runs **on the phone** with Google MediaPipe. No video leaves the device.

The host app writes no exercise UI. It shows one component and receives numbers back.

```tsx
import { RehabSession, preloadModels, type RehabEngineResult } from 'rehab-sdk';

// When the mini app opens: download the AI models in the background (once; again only if a URL changes).
preloadModels(/* optional { pose, hand } URLs on your own server */);

<RehabSession
  exercise="raise"                              // raise | lateral | curl | wrist | pinch
  targetReps={10}                               // optional: shows "3 / 10" and finishes at 10
  onFinish={(result) => upload(result)}         // 完成 tapped or target reached
  onCancel={() => goBack()}                     // optional: shows 取消
  onRep={(soFar) => saveProgress(soFar)}        // optional: result so far after every rep
  modelUrls={{ pose: 'https://…', hand: 'https://…' }} // optional; defaults to Google's public files
/>
```

The result is **the same JSON as the native SDK (rehab-engine)**: reps, per-rep peak, start, range,
duration, hold time and compensations, attempts that missed the target, compensation counts, an angle
series every 200 ms, tracking ratio, targetReps and completed. See `src/engine/types.ts`. The rules,
thresholds and compensation checks are a port of the native SDK's, so the same movement gives the same numbers.

## Exercises

| id | Name | Model | Compensation checks |
|---|---|---|---|
| `raise` | 舉手過頭 | Pose | trunkLean, shoulderHike, elbowBent |
| `lateral` | 側平舉 | Pose | trunkLean, shoulderHike, elbowBent |
| `curl` | 屈手肘 | Pose | upperArmSwing, trunkLean |
| `wrist` | 手腕屈伸 | Pose | forearmMove |
| `pinch` | 拇指對食指 | Hand | fingersCurled |

## What the host app must provide

The SDK's native parts are built into the host binary. JavaScript (UI and rules) can be updated over the air.
**Expo is not required. No patches, codegen settings or Podfile changes.**

1. **Peer dependencies** (exact versions recommended): `react-native-vision-camera@4.7.3`,
   `react-native-worklets-core@1.6.3`, `react-native-svg@15.8.0`.
2. **New Architecture** enabled. iOS pods built as **static frameworks** (`use_frameworks! :linkage => :static`
   in the Podfile, or `expo-build-properties` → `ios.useFrameworks: "static"` in Expo apps).
3. **Babel**: `react-native-worklets-core/plugin` in `babel.config.js`.
4. **Camera permission**: `NSCameraUsageDescription` in Info.plist; `CAMERA` in AndroidManifest.
5. Rebuild the native app after installing: the SDK adds its own native parts (below), found by autolinking.

The SDK's native parts are its own code, not third-party packages: VisionCamera frame processor plugins
`poseLandmarks` and `handLandmarks` that call Google MediaPipe Tasks Vision directly (the same library as the
native SDK), and the model downloader. Hand tracking (pinch) now works on Android too.

## Packing a tarball for another app

```bash
cd packages/rehab-sdk
rm -f assets/models/*.task   # models are downloaded at run time; keep them out of the tarball
npm pack                     # → rehab-sdk-0.5.0.tgz
```

In the consuming app: `npm install /path/to/rehab-sdk-0.5.0.tgz`, then rebuild the native app (`pod install` on iOS; Expo apps `npx expo prebuild --clean`).

## What is inside

| Path | Contents |
|---|---|
| `src/RehabSession.tsx` | The screen component and its public props |
| `src/engine/` | Exercise rules, compensations, rep counter and result (port of the native SDK, unit tested) |
| `src/pose/`, `src/hand/` | Pose and hand frame processor hooks, screen mapping, smoothing |
| `src/components/`, `src/ui/` | Skeleton, hand overlay, dial, cue, rep counter, theme |
| `ios/`, `RehabSdk.podspec` | iOS: pose and hand frame processor plugins (MediaPipe), model downloader |
| `android/` | Android: pose and hand frame processor plugins (MediaPipe), model downloader |
| `app.plugin.js` | Empty Expo config plugin (kept for apps that list it) |
