Pod::Spec.new do |s|
  s.name         = 'RehabSdk'
  s.version      = '0.5.0'
  s.summary      = 'rehab-sdk native parts: MediaPipe Pose and Hand Landmarker frame processor plugins and the model downloader'
  s.homepage     = 'https://github.com/elephantplan/motion_app'
  s.license      = 'MIT'
  s.authors      = 'motion_app'
  s.platforms    = { :ios => '15.1' }
  s.source       = { :git => 'https://github.com/elephantplan/motion_app.git' }
  s.source_files = 'ios/**/*.{h,m,mm,swift}'
  s.swift_version = '5.0'
  s.pod_target_xcconfig = { 'DEFINES_MODULE' => 'YES' }
  # Offline-first builds: run download-model.sh before packing and the models ship in the app.
  s.resources    = Dir.glob(File.join(__dir__, 'assets/models/*.task')).map { |f| f.sub("#{__dir__}/", '') }

  # Same MediaPipe pod as the native SDK (rehab-engine).
  s.dependency 'MediaPipeTasksVision', '~> 0.10.14'
  s.dependency 'VisionCamera'
  s.dependency 'React-Core'
end
