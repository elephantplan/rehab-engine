package com.rehabsdk

import com.google.mediapipe.framework.image.MediaImageBuilder
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.mrousavy.camera.frameprocessors.Frame
import com.mrousavy.camera.frameprocessors.FrameProcessorPlugin
import com.mrousavy.camera.frameprocessors.VisionCameraProxy

/**
 * VisionCamera frame processor plugin "handLandmarks": runs MediaPipe Hand Landmarker and returns
 * 21 points per hand, the same shape as the iOS plugin.
 */
class HandLandmarkerPlugin(proxy: VisionCameraProxy, options: Map<String, Any>?) : FrameProcessorPlugin() {
  private var landmarker: HandLandmarker? = null
  private var loadError: String? = null
  private var lastTimestamp = 0L

  init {
    val model = options?.get("model") as? String ?: "hand_landmarker.task"
    val numHands = (options?.get("numHands") as? Number)?.toInt() ?: 1
    try {
      landmarker = ModelLoader.withFallback { delegate ->
        HandLandmarker.createFromOptions(
          proxy.context,
          HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(ModelLoader.baseOptions(model, delegate))
            .setRunningMode(RunningMode.VIDEO)
            .setNumHands(numHands)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .build(),
        )
      }
    } catch (e: Exception) {
      loadError = e.message ?: "Hand landmarker could not be created"
    }
  }

  override fun callback(frame: Frame, params: Map<String, Any>?): Any? {
    val landmarker = landmarker ?: return mapOf("error" to (loadError ?: "Hand landmarker not created"))
    return try {
      val image = MediaImageBuilder(frame.image).build()
      lastTimestamp = maxOf(System.currentTimeMillis(), lastTimestamp + 1)
      val options = ImageProcessingOptions.builder().setRotationDegrees(0).build()
      val result = landmarker.detectForVideo(image, options, lastTimestamp)
      mapOf(
        "width" to image.width.toDouble(),
        "height" to image.height.toDouble(),
        "hands" to result.landmarks().map { hand -> hand.map { listOf(it.x().toDouble(), it.y().toDouble(), it.z().toDouble()) } },
        "handedness" to result.handedness().map { it.firstOrNull()?.categoryName() ?: "" },
      )
    } catch (e: Exception) {
      mapOf("error" to (e.message ?: "Hand detection failed"))
    }
  }
}
