package com.rehabsdk

import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import java.io.RandomAccessFile
import java.nio.channels.FileChannel

/**
 * Model options shared by the pose and hand plugins. An absolute path is a model downloaded at
 * run time (mapped into memory, since setModelAssetPath only reads the APK's assets); a bare name
 * is a model bundled into the app's assets.
 */
internal object ModelLoader {
  fun baseOptions(model: String, delegate: Delegate): BaseOptions {
    val b = BaseOptions.builder().setDelegate(delegate)
    if (model.startsWith("/")) {
      RandomAccessFile(model, "r").use { f ->
        b.setModelAssetBuffer(f.channel.map(FileChannel.MapMode.READ_ONLY, 0, f.length()))
      }
    } else {
      b.setModelAssetPath(model)
    }
    return b.build()
  }

  /** GPU first; some phones cannot run the model on the GPU, so fall back to the CPU. */
  fun <T> withFallback(create: (Delegate) -> T): T =
    try {
      create(Delegate.GPU)
    } catch (e: RuntimeException) {
      create(Delegate.CPU)
    }
}
