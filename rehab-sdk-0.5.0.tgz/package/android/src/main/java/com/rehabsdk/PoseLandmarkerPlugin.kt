package com.rehabsdk

import com.google.mediapipe.framework.image.MediaImageBuilder
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker
import com.mrousavy.camera.frameprocessors.Frame
import com.mrousavy.camera.frameprocessors.FrameProcessorPlugin
import com.mrousavy.camera.frameprocessors.VisionCameraProxy

/**
 * VisionCamera frame processor plugin "poseLandmarks": runs MediaPipe Pose Landmarker on a frame
 * and returns the first person's 33 points, normalised to the frame as the camera delivered it
 * (the JS side rotates and mirrors them onto the screen). Replaces react-native-mediapipe-posedetection.
 */
class PoseLandmarkerPlugin(proxy: VisionCameraProxy, options: Map<String, Any>?) : FrameProcessorPlugin() {
  private var landmarker: PoseLandmarker? = null
  private var loadError: String? = null
  private var lastTimestamp = 0L

  init {
    val model = options?.get("model") as? String ?: "pose_landmarker_full.task"
    try {
      landmarker = ModelLoader.withFallback { delegate ->
        PoseLandmarker.createFromOptions(
          proxy.context,
          PoseLandmarker.PoseLandmarkerOptions.builder()
            .setBaseOptions(ModelLoader.baseOptions(model, delegate))
            .setRunningMode(RunningMode.VIDEO)
            .setNumPoses(1)
            .setMinPoseDetectionConfidence(0.5f)
            .setMinPosePresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .build(),
        )
      }
    } catch (e: Exception) {
      loadError = e.message ?: "Pose landmarker could not be created"
    }
  }

  override fun callback(frame: Frame, params: Map<String, Any>?): Any? {
    val landmarker = landmarker ?: return mapOf("error" to (loadError ?: "Pose landmarker not created"))
    return try {
      val image = MediaImageBuilder(frame.image).build()
      // Video mode needs strictly increasing timestamps.
      lastTimestamp = maxOf(System.currentTimeMillis(), lastTimestamp + 1)
      val options = ImageProcessingOptions.builder().setRotationDegrees(0).build()
      val result = landmarker.detectForVideo(image, options, lastTimestamp)
      val pose = result.landmarks().firstOrNull()
      mapOf(
        "width" to image.width.toDouble(),
        "height" to image.height.toDouble(),
        "landmarks" to (pose?.map {
          listOf(it.x().toDouble(), it.y().toDouble(), it.z().toDouble(), it.visibility().orElse(1f).toDouble())
        } ?: emptyList<List<Double>>()),
      )
    } catch (e: Exception) {
      mapOf("error" to (e.message ?: "Pose detection failed"))
    }
  }
}
