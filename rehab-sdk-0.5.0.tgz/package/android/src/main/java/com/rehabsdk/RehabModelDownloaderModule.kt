package com.rehabsdk

import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Downloads an AI model file once and keeps it in the app's files folder. A different URL for
 * the same file name downloads it again. Replaces expo-file-system, so host apps need no Expo.
 */
class RehabModelDownloaderModule(context: ReactApplicationContext) : ReactContextBaseJavaModule(context) {
  override fun getName() = "RehabModelDownloader"

  @ReactMethod
  fun download(url: String, fileName: String, promise: Promise) {
    Thread {
      try {
        val dir = File(reactApplicationContext.filesDir, "rehab-models").apply { mkdirs() }
        val file = File(dir, fileName)
        val meta = File(dir, "$fileName.url")
        if (file.exists() && meta.exists() && meta.readText() == url) {
          promise.resolve(file.absolutePath)
          return@Thread
        }
        val tmp = File(dir, "$fileName.download")
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
          connectTimeout = 15_000
          readTimeout = 30_000
          instanceFollowRedirects = true
        }
        try {
          val code = conn.responseCode
          if (code !in 200..299) {
            promise.reject("model_download_failed", "Model download failed ($code): $url")
            return@Thread
          }
          conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
        } finally {
          conn.disconnect()
        }
        // Moved into place only after a complete download, so a cut-off one is never used.
        file.delete()
        if (!tmp.renameTo(file)) throw IOException("Could not move ${tmp.name} into place")
        meta.writeText(url)
        promise.resolve(file.absolutePath)
      } catch (e: Exception) {
        promise.reject("model_download_failed", e.message ?: "Model download failed: $url", e)
      }
    }.start()
  }
}
