package com.rehabsdk

import android.util.Log
import com.facebook.react.ReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.ViewManager
import com.mrousavy.camera.frameprocessors.FrameProcessorPluginRegistry

/** Found by React Native autolinking; registers the model downloader and the two frame processor plugins. */
class RehabSdkPackage : ReactPackage {
  companion object {
    init {
      // Registered when the package class loads, before any frame processor asks for them.
      try {
        FrameProcessorPluginRegistry.addFrameProcessorPlugin("poseLandmarks") { proxy, options -> PoseLandmarkerPlugin(proxy, options) }
        FrameProcessorPluginRegistry.addFrameProcessorPlugin("handLandmarks") { proxy, options -> HandLandmarkerPlugin(proxy, options) }
      } catch (e: Throwable) {
        Log.e("RehabSdk", "Could not register frame processor plugins", e)
      }
    }
  }

  override fun createNativeModules(context: ReactApplicationContext): List<NativeModule> =
    listOf(RehabModelDownloaderModule(context))

  override fun createViewManagers(context: ReactApplicationContext): List<ViewManager<*, *>> = emptyList()
}
