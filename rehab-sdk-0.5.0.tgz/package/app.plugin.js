// Expo config plugin, kept so Expo apps that list "rehab-sdk" in app.json keep building.
// Since 0.5.0 the SDK needs no project changes from a plugin: its native parts are autolinked.
module.exports = function withRehabSdk(config) {
  return config;
};
