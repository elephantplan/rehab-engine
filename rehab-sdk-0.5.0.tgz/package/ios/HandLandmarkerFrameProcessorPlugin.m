#import <Foundation/Foundation.h>
#import <VisionCamera/FrameProcessorPlugin.h>
#import <VisionCamera/FrameProcessorPluginRegistry.h>
#import <VisionCamera/Frame.h>

// Registers the Swift plugins with VisionCamera as "handLandmarks" and "poseLandmarks".
// Uses an ObjC class with +load and a runtime class lookup, the same way
// react-native-mediapipe-posedetection registers its plugin (which works in this app's
// static-framework build), instead of VisionCamera's category-constructor macro.
@interface HandLandmarkerPluginLoader : NSObject
@end

@implementation HandLandmarkerPluginLoader

+ (void)registerPlugin:(NSString *)name swiftClass:(NSString *)className
{
  Class pluginClass = NSClassFromString(className);
  if (pluginClass == nil) {
    NSLog(@"[RehabSdk] Swift class %@ not found; plugin %@ not registered", className, name);
    return;
  }
  [FrameProcessorPluginRegistry addFrameProcessorPlugin:name
                                        withInitializer:^FrameProcessorPlugin *(VisionCameraProxyHolder *proxy,
                                                                                NSDictionary *options) {
    return [[pluginClass alloc] initWithProxy:proxy withOptions:options];
  }];
}

+ (void)load
{
  [self registerPlugin:@"handLandmarks" swiftClass:@"HandLandmarkerFrameProcessorPlugin"];
  [self registerPlugin:@"poseLandmarks" swiftClass:@"PoseLandmarkerFrameProcessorPlugin"];
}

@end
