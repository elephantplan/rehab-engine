import Foundation
import UIKit
import VisionCamera
import MediaPipeTasksVision

/// Runs MediaPipe Pose Landmarker on a camera frame and returns the first person's 33 points,
/// normalised to the frame (the JS side rotates and mirrors them onto the screen).
/// Called synchronously from a JS frame processor: `plugin.call(frame, { orientation })`.
/// Replaces react-native-mediapipe-posedetection.
@objc(PoseLandmarkerFrameProcessorPlugin)
public class PoseLandmarkerFrameProcessorPlugin: FrameProcessorPlugin {
  private var landmarker: PoseLandmarker?
  private var loadError: String?
  private var lastTimestamp = 0

  public override init(proxy: VisionCameraProxyHolder, options: [AnyHashable: Any]! = [:]) {
    super.init(proxy: proxy, options: options)
    let model = (options?["model"] as? String) ?? "pose_landmarker_full.task"
    guard let path = HandLandmarkerFrameProcessorPlugin.modelPath(model) else {
      loadError = "Model not found: \(model)"
      return
    }
    let o = PoseLandmarkerOptions()
    o.baseOptions.modelAssetPath = path
    o.baseOptions.delegate = .GPU
    o.runningMode = .video
    o.numPoses = 1
    o.minPoseDetectionConfidence = 0.5
    o.minPosePresenceConfidence = 0.5
    o.minTrackingConfidence = 0.5
    do {
      landmarker = try PoseLandmarker(options: o)
    } catch {
      loadError = error.localizedDescription
    }
  }

  public override func callback(_ frame: Frame, withArguments arguments: [AnyHashable: Any]?) -> Any? {
    guard let landmarker else { return ["error": loadError ?? "Pose landmarker not created"] }
    let orientation = HandLandmarkerFrameProcessorPlugin.uiOrientation(arguments?["orientation"] as? String)
    guard let image = try? MPImage(sampleBuffer: frame.buffer, orientation: orientation) else { return nil }

    // Video mode needs strictly increasing timestamps.
    let now = Int(Date().timeIntervalSince1970 * 1000)
    lastTimestamp = max(now, lastTimestamp + 1)

    do {
      let result = try landmarker.detect(videoFrame: image, timestampInMilliseconds: lastTimestamp)
      let pose: [[Double]] = (result.landmarks.first ?? []).map {
        [Double($0.x), Double($0.y), Double($0.z), Double(truncating: $0.visibility ?? 1)]
      }
      return ["width": Double(image.width), "height": Double(image.height), "landmarks": pose]
    } catch {
      return ["error": error.localizedDescription]
    }
  }
}
