#import <React/RCTBridgeModule.h>

// Exposes the Swift RehabModelDownloader to JavaScript as NativeModules.RehabModelDownloader.
@interface RCT_EXTERN_MODULE(RehabModelDownloader, NSObject)
RCT_EXTERN_METHOD(download:(NSString *)url
                  fileName:(NSString *)fileName
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
@end
