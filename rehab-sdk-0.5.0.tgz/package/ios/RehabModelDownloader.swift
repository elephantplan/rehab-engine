import Foundation
import React

/// Downloads an AI model file once and keeps it in Application Support. A different URL for the
/// same file name downloads it again (that is how a model is updated without an app release).
/// Replaces expo-file-system, so host apps need no Expo modules.
@objc(RehabModelDownloader)
class RehabModelDownloader: NSObject {
  @objc static func requiresMainQueueSetup() -> Bool { false }

  @objc func download(_ url: String, fileName: String,
                      resolver resolve: @escaping RCTPromiseResolveBlock,
                      rejecter reject: @escaping RCTPromiseRejectBlock) {
    guard let remote = URL(string: url) else {
      reject("model_download_failed", "Invalid model URL: \(url)", nil)
      return
    }
    let fm = FileManager.default
    do {
      let dir = try fm.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        .appendingPathComponent("rehab-models", isDirectory: true)
      try fm.createDirectory(at: dir, withIntermediateDirectories: true)
      let file = dir.appendingPathComponent(fileName)
      let meta = dir.appendingPathComponent(fileName + ".url")
      if fm.fileExists(atPath: file.path), (try? String(contentsOf: meta, encoding: .utf8)) == url {
        resolve(file.path)
        return
      }
      URLSession.shared.downloadTask(with: remote) { tmp, response, error in
        if let error {
          reject("model_download_failed", error.localizedDescription, error)
          return
        }
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        guard let tmp, (200..<300).contains(status) else {
          reject("model_download_failed", "Model download failed (\(status)): \(url)", nil)
          return
        }
        do {
          // Moved into place only after a complete download, so a cut-off one is never used.
          try? fm.removeItem(at: file)
          try fm.moveItem(at: tmp, to: file)
          try url.write(to: meta, atomically: true, encoding: .utf8)
          resolve(file.path)
        } catch {
          reject("model_download_failed", error.localizedDescription, error)
        }
      }.resume()
    } catch {
      reject("model_download_failed", error.localizedDescription, error)
    }
  }
}
