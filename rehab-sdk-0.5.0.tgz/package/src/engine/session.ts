// One exercise session: feeds each frame's reading to the rep counter, samples the value for the
// series, tracks how often the patient was in view, and builds the result in the native SDK's
// format.
import { Exercise, type Reading } from './exercises';
import { RepCounter } from './repCounter';
import type { RehabEngineResult, RehabSide } from './types';

export const SDK_VERSION = '0.5.0';
const SERIES_INTERVAL_MS = 200;
/** 10 minutes at 5 samples a second. */
const SERIES_CAP = 3000;

export class Session {
  readonly exercise: Exercise;
  readonly counter: RepCounter;
  readonly startedAt: number;
  /** The side followed so far ('both' for lateral). */
  trackedSide: RehabSide = null;
  private readonly startMs: number;
  private readonly series: (number | null)[] = [];
  private lastSampleAt: number | null = null;
  private framesSeen = 0;
  private framesTracked = 0;

  constructor(exerciseId: string | undefined, readonly targetReps: number, private readonly model: string, now = Date.now()) {
    this.exercise = new Exercise(exerciseId);
    this.startMs = now;
    this.startedAt = now;
    this.counter = new RepCounter(this.exercise.config, now);
  }

  /** `usable`: the landmarks the exercise needs were in view this frame. */
  step(reading: Reading, usable: boolean, now = Date.now()) {
    this.framesSeen += 1;
    if (usable) this.framesTracked += 1;
    if (reading.side != null) this.trackedSide = reading.side;
    this.counter.step(reading.value, reading.side, now, reading.compensations, reading.shrug, reading.forearm);
    if (this.series.length < SERIES_CAP && (this.lastSampleAt == null || now - this.lastSampleAt >= SERIES_INTERVAL_MS)) {
      this.series.push(this.counter.value);
      this.lastSampleAt = now;
    }
  }

  get completed() {
    return this.targetReps > 0 && this.counter.reps >= this.targetReps;
  }

  result(now = Date.now()): RehabEngineResult {
    const ex = this.exercise;
    const degrees = ex.unit === 'degrees';
    // Angles as whole degrees, ratios to two decimals, the same as the native SDK.
    const num = (v: number) => (degrees ? Math.round(v) : Math.round(v * 100) / 100);
    const c = this.counter;
    const compensations: RehabEngineResult['compensations'] = {};
    for (const k of ex.compensationChecks) compensations[k] = 0;
    for (const k of [...c.repDetails, ...c.attempts].flatMap((r) => r.compensations)) {
      compensations[k] = (compensations[k] ?? 0) + 1;
    }
    return {
      exercise: ex.id,
      unit: ex.unit,
      reps: c.reps,
      durationMs: now - this.startMs,
      startedAt: this.startedAt,
      best: c.best == null ? null : num(c.best),
      target: { activeAt: num(ex.config.activeAt), restAt: num(ex.config.restAt) },
      repDetails: c.repDetails.map((r) => ({
        peak: num(r.peak), start: num(r.start), range: num(Math.abs(r.peak - r.start)),
        durationMs: r.durationMs, holdMs: r.holdMs, atMs: r.atMs, side: r.side, compensations: r.compensations,
      })),
      attempts: c.attempts.map((a) => ({
        peak: num(a.peak), start: num(a.start), atMs: a.atMs, side: a.side, compensations: a.compensations,
      })),
      compensations,
      series: { intervalMs: SERIES_INTERVAL_MS, values: this.series.map((v) => (v == null ? null : num(v))) },
      trackingRatio: this.framesSeen > 0 ? this.framesTracked / this.framesSeen : 0,
      targetReps: this.targetReps > 0 ? this.targetReps : null,
      completed: this.targetReps > 0 ? c.reps >= this.targetReps : null,
      sdkVersion: SDK_VERSION,
      model: this.model,
    };
  }
}
