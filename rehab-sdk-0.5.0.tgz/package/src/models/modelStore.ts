// Downloads the MediaPipe model files at run time and keeps them on the phone, so the host app's
// install does not carry them. Call preloadModels() when the mini app opens; RehabSession waits
// for the files (and downloads them itself if preload was skipped). The download itself is done by
// the SDK's own small native module (ios/RehabModelDownloader.swift, android/…/RehabModelDownloaderModule.kt).
import { NativeModules } from 'react-native';

export type ModelName = 'pose' | 'hand';
export type ModelUrls = Partial<Record<ModelName, string>>;
/** Absolute file paths (no file:// prefix), as the native MediaPipe code expects. */
export type ModelPaths = Record<ModelName, string>;

/** Google's public files. Production apps should host copies on their own server and pass modelUrls. */
export const DEFAULT_MODEL_URLS: Record<ModelName, string> = {
  pose: 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/latest/pose_landmarker_full.task',
  hand: 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task',
};

const FILE_NAMES: Record<ModelName, string> = { pose: 'pose_landmarker.task', hand: 'hand_landmarker.task' };

type Downloader = { download(url: string, fileName: string): Promise<string> };
const native = NativeModules.RehabModelDownloader as Downloader | undefined;

// One download per model at a time, shared by preload and RehabSession.
const inFlight = new Map<string, Promise<string>>();

/** Downloads the file if it is missing or came from a different URL; resolves with its absolute path. */
function ensureModel(name: ModelName, url: string): Promise<string> {
  if (!native) {
    return Promise.reject(new Error('RehabModelDownloader native module not found: rebuild the app after installing rehab-sdk'));
  }
  const key = `${name}|${url}`;
  const running = inFlight.get(key);
  if (running) return running;
  const job = native.download(url, FILE_NAMES[name]).finally(() => inFlight.delete(key));
  inFlight.set(key, job);
  return job;
}

/**
 * Makes sure the model files are on the phone. Downloads only what is missing or whose URL changed.
 * Call it when the mini app opens so the exercise screen starts without waiting.
 */
export async function preloadModels(urls: ModelUrls = {}, onProgress?: (fraction: number) => void): Promise<ModelPaths> {
  const all = { ...DEFAULT_MODEL_URLS, ...urls };
  // Progress is per file: 0 at start, 0.5 when the first is ready, 1 when both are.
  let done = 0;
  const track = (p: Promise<string>) => p.then((path) => { done += 1; onProgress?.(done / 2); return path; });
  onProgress?.(0);
  const [pose, hand] = await Promise.all([track(ensureModel('pose', all.pose)), track(ensureModel('hand', all.hand))]);
  onProgress?.(1);
  return { pose, hand };
}
