import { Platform } from 'react-native';
import { KEYPOINT_NAMES, Keypoint, KeypointName } from './types';

/**
 * iOS front-camera frames reach MediaPipe mirrored, so its "left" is the person's right.
 * Swapping the names makes 左手 / 右手 mean the person's own hands.
 */
const SWAP_SIDES = Platform.OS === 'ios';
const NAME_AT = KEYPOINT_NAMES.map((name) =>
  SWAP_SIDES ? ((name.startsWith('left') ? name.replace('left', 'right') : name.replace('right', 'left')) as KeypointName) : name,
);

/** MediaPipe's [x, y, z, visibility] points (normalised) → keypoints in screen pixels. */
export function imageToScreen(image: number[][], toView: (p: { x: number; y: number }) => { x: number; y: number }): Keypoint[] {
  return KEYPOINT_NAMES.map((_, i) => {
    const name = NAME_AT[i];
    const l = image[i];
    if (!l) return { name, x: 0, y: 0, score: 0 };
    const p = toView({ x: l[0], y: l[1] });
    return { name, x: p.x, y: p.y, score: l[3] ?? 1 };
  });
}
