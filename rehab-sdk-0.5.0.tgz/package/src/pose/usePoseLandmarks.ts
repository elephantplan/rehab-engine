import { useMemo } from 'react';
import { VisionCameraProxy, runAtTargetFps, useFrameProcessor, type Orientation } from 'react-native-vision-camera';
import { Worklets } from 'react-native-worklets-core';

export type PoseResult = {
  width: number;
  height: number;
  /** The first person's 33 points: [x, y, z, visibility], x and y normalised to the frame. Empty when nobody is seen. */
  landmarks: number[][];
  error?: string;
};

// About the rate the old pose library ran at; keeps older phones responsive.
const POSE_FPS = 15;

// One plugin instance per model file; the plugin loads the model when it is created.
const plugins = new Map<string, ReturnType<typeof VisionCameraProxy.initFrameProcessorPlugin>>();
function pluginFor(modelPath: string) {
  if (!plugins.has(modelPath)) {
    plugins.set(modelPath, VisionCameraProxy.initFrameProcessorPlugin('poseLandmarks', { model: modelPath }));
  }
  return plugins.get(modelPath);
}

/**
 * A frame processor that runs the SDK's MediaPipe Pose Landmarker plugin and hands results to
 * `onResult` on the JS thread. `modelPath` is the downloaded pose model (absolute file path).
 */
export function usePoseLandmarks(onResult: (r: PoseResult, frameOrientation: Orientation) => void, modelPath: string) {
  const plugin = useMemo(() => pluginFor(modelPath), [modelPath]);
  const onResultJS = useMemo(() => Worklets.createRunOnJS(onResult), [onResult]);
  const frameProcessor = useFrameProcessor(
    (frame) => {
      'worklet';
      if (plugin == null) return;
      runAtTargetFps(POSE_FPS, () => {
        'worklet';
        const r = plugin.call(frame, { orientation: 'portrait' });
        if (r != null) onResultJS(r as unknown as PoseResult, frame.orientation);
      });
    },
    [onResultJS, plugin],
  );
  return { frameProcessor, available: plugin != null };
}
