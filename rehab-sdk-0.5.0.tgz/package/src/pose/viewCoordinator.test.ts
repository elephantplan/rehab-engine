import { ViewCoordinator } from './viewCoordinator';

describe('ViewCoordinator (same mapping as react-native-mediapipe-posedetection)', () => {
  it('portrait frame, same aspect as the view: plain scaling', () => {
    const vc = new ViewCoordinator({ width: 100, height: 200 }, false, 'portrait');
    const f = vc.frameDims(300, 600);
    expect(f).toEqual({ width: 300, height: 600 });
    expect(vc.toView(f, { x: 0.5, y: 0.25 })).toEqual({ x: 50, y: 50 });
  });

  it('mirrors horizontally when asked (Android front camera)', () => {
    const vc = new ViewCoordinator({ width: 100, height: 200 }, true, 'portrait');
    expect(vc.toView(vc.frameDims(300, 600), { x: 0.1, y: 0.5 }).x).toBeCloseTo(90);
  });

  it('sideways frame: swaps width and height and rotates points', () => {
    // A landscape-left frame (sensor sideways) shown on a portrait screen.
    const vc = new ViewCoordinator({ width: 100, height: 200 }, false, 'landscape-left');
    const f = vc.frameDims(600, 300);
    expect(f).toEqual({ width: 300, height: 600 });
    // Rotation +90: (x, y) → (y, 1 − x).
    expect(vc.toView(f, { x: 0, y: 0 })).toEqual({ x: 0, y: 200 });
  });

  it('cover: crops the longer side and centres', () => {
    const vc = new ViewCoordinator({ width: 100, height: 100 }, false, 'portrait');
    const f = vc.frameDims(100, 200); // taller than the view → width fills, height cropped
    expect(vc.toView(f, { x: 0.5, y: 0.5 })).toEqual({ x: 50, y: 50 });
    expect(vc.toView(f, { x: 0, y: 0 })).toEqual({ x: 0, y: -50 });
  });
});
