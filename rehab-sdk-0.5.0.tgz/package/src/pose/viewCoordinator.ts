// Maps normalised MediaPipe points from a camera frame onto the camera view on screen: rotate to
// the screen's orientation, scale like resizeMode "cover", and mirror for the front camera.
// Adapted from react-native-mediapipe-posedetection (MIT, (c) 2025 Mantu), whose mapping was
// verified on device; kept identical so the skeleton lines up the same way.
import type { Orientation } from 'react-native-vision-camera';

type Dims = { width: number; height: number };
type Point = { x: number; y: number };

const DEGREES: Record<Orientation, number> = {
  portrait: 0, 'landscape-left': 90, 'portrait-upside-down': 180, 'landscape-right': 270,
};

function orientationOf(degrees: number): Orientation {
  const d = (degrees + 360) % 360;
  if (d >= 315 || d <= 45) return 'portrait';
  if (d <= 135) return 'landscape-left';
  if (d <= 225) return 'portrait-upside-down';
  return 'landscape-right';
}

const ROTATION: Record<Orientation, number> = {
  'landscape-left': -90, portrait: 0, 'landscape-right': 90, 'portrait-upside-down': 180,
};

function rotate(p: Point, rotation: number): Point {
  if (rotation === 90) return { x: p.y, y: 1 - p.x };
  if (rotation === 180) return { x: 1 - p.x, y: 1 - p.y };
  if (rotation === -90 || rotation === 270) return { x: 1 - p.y, y: p.x };
  return p;
}

export class ViewCoordinator {
  private readonly orientation: Orientation;
  private readonly rotation: number;

  /**
   * `frameOrientation` is the frame's orientation (frame.orientation in the frame processor);
   * the screen is portrait. `mirrored`: flip horizontally (Android front camera).
   */
  constructor(private readonly view: Dims, private readonly mirrored: boolean, frameOrientation: Orientation) {
    this.orientation = orientationOf(DEGREES.portrait - DEGREES[frameOrientation]);
    this.rotation = ROTATION[this.orientation];
  }

  /** Frame size as seen on screen (width and height swap for sideways frames). */
  frameDims(width: number, height: number): Dims {
    return this.orientation === 'portrait' || this.orientation === 'portrait-upside-down'
      ? { width, height }
      : { width: height, height: width };
  }

  /** Normalised point (0...1) in the frame → screen pixels inside the camera view. */
  toView(frame: Dims, p: Point): Point {
    const r = rotate(p, this.rotation);
    let x = r.x * frame.width;
    const y = r.y * frame.height;
    if (this.mirrored) x = frame.width - x;
    // resizeMode "cover": fill the view, cropping the longer side.
    const frameRatio = frame.width / frame.height;
    const viewRatio = this.view.width / this.view.height;
    const scale = frameRatio > viewRatio ? this.view.height / frame.height : this.view.width / frame.width;
    const xoffset = (this.view.width - frame.width * scale) / 2;
    const yoffset = (this.view.height - frame.height * scale) / 2;
    return { x: x * scale + xoffset, y: y * scale + yoffset };
  }
}
